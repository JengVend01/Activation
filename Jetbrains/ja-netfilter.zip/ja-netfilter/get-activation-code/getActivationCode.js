const licenseInfo = {
    "name": "Jeng Vend",
    "user": "Jeng Vend",
    "mail": "zyp+jetbrains@outlook.it",
    "time": "2031-12-31"
}

// 生成激活码并复制到剪切板
async function createAndPaste() {
    // 获取所有支持激活的编译器及插件的code字符串(英文逗号隔开)
    // 可通过codes.md获取
    let codes = "";
    array_codes.forEach(o => {
        codes += o.code + ","
    });
    let data = await buildLicense(codes);
    console.log(data)
}

async function buildLicense(productCode) {
    let licenseId = genLicenseId()
    let licensePartJson = buildLicensePartJson(productCode, licenseId)
    let privateKey = await window.crypto.subtle.importKey("pkcs8", base64ToArrayBuffer(pem2base64(pemEncodedKey)), {
        name: "RSASSA-PKCS1-v1_5",
        hash: "SHA-1",
    }, true, ["sign"]);
    let licensePartBase64 = btoa(unescape(encodeURIComponent(licensePartJson)));
    let sigResultsBase64 = arrayBufferToBase64(await window.crypto.subtle.sign("RSASSA-PKCS1-v1_5", privateKey, new TextEncoder().encode(licensePartJson)));
    let cert_base64 = pem2base64(pemEncodedCrt);
    return `${licenseId}-${licensePartBase64}-${sigResultsBase64}-${cert_base64}`;
}

function genLicenseId() {
    const CHARSET = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    return Array.from({
        length: 10
    }, () => {
        let idx = Math.floor(Math.random() * CHARSET.length);
        return CHARSET[idx];
    }
    ).join('');
}


function buildLicensePartJson(productCode, licenseId) {
    let products = [];
    productCode = productCode.split(",");
    for (let code of productCode) {
        products.push({
            code: code,
            fallbackDate: licenseInfo.time,
            paidUpTo: licenseInfo.time
        });
    }
    return JSON.stringify({
        "licenseId": licenseId,
        "licenseeName": licenseInfo.name,
        "assigneeName": licenseInfo.name,
        "assigneeEmail": licenseInfo.mail,
        "licenseRestriction": "",
        "checkConcurrentUse": false,
        "products": products,
        "metadata": "0120230102PPAA013009",
        "hash": "41472961/0:1563609451",
        "gracePeriodDays": 7,
        "autoProlongated": true,
        "isAutoProlongated": true
    });
}


function base64ToArrayBuffer(base64) {
    return Uint8Array.from(atob(base64), c => c.charCodeAt(0)).buffer;
}
function arrayBufferToBase64(buffer) {
    return btoa([...new Uint8Array(buffer)].map(b => String.fromCharCode(b)).join(''));
}
function pem2base64(pem) {
    return pem.split('\n').reduce( (base64, line) => line.includes("--") ? base64 : base64 + line, '');
}




const pemEncodedKey = `-----BEGIN PRIVATE KEY-----
MIIJQgIBADANBgkqhkiG9w0BAQEFAASCCSwwggkoAgEAAoICAQC3p6nBj9mcRpGK
pigPXOB83/PmA9bJr5jsSo3fm5ky67rTP4V79XI9a1t/5asg7XQ5OyulvP0w6tQk
axLfg6Opd9A8YQIgt+Gh/A5hsIKu+8RKC4prx+S6Xj8X5RfrWwdUWbRYBQziGC3U
kGihR9iQ4FSsYS4ld0uo54j4ZArVlq07PhOr6uDdeQZtzZzOQCSC6o7VGzozX2sV
aukazqE3NEdxaqqOsr8aP/iWGtlJxyAvq9nWyrgyzFK7YJ8nRFHSTV9Mx/RbXHRC
76+PLnPZmNN/E1lLGVCtaZ0G8QNmz8gOKp2CfSL1IDui7S17xhZtd+2EDEtTeNQB
wwTq8KDSPFKA1/qiN6zPem4hThb5+xHZMu6wcs8m7dx/s8XaI3476S9RNDTvfAU/
c37nxwGgMWbZZgzruSwyXtwhrq58kTERMW7XPkI5dZlIerRuJWpAMHbKMa8tBnRu
9smmMm/Yred5GhZLP0/7O2e20Sc1Rc0A1dWOG81LZON7yptr87QVZUJAZGWOX9iW
3uSIN2/LMEMwZzk9Jqy+Uj1IcJkOiMZBFs7Y+eThLowTJka/dqBErqvWWDGni4nS
llUd//vhwPAUWWkRhCrUh2QmxRBXYoQ8cSb/V4ejbk/3sCeh2KftDUKRZ1Jye9p/
MFfrbnaWpu2inHc1Zs+3DcDoRti7OwIDAQABAoICABM991zG6BtmD2ix+P+HESQ0
SLcgTthJ1CFpvEyh3l7F8QiiHqe6szH5NhiD5TapemRmrS+LyhFegUShjVQq1DJ0
0bYJyfHIolTY9l7I4iBYU5wYcnPReUcHid/EiomHu5BcZ7dTLCLiOqcLTFMdlnSz
dFutQOr/AUfcnm67+KChTVwoKGJ6VP4PaJuHj/bSJKEs1zM/y4zHYg5X6b17ycth
aFzbOqyB0OD8s9xySrLesKIeBNBq4/q6iq6ENJimIVaB8cq3JoSN/sZmm4PKb6vs
RbiKO/BQ4jGRH7ky9lLG0WSelWsvFkMNkgIDjKDrw7zLdHDB4wCHZ9sZZkIBXTAL
6ktSBFq2IMuyn3C6hhbYWHADOo7x/RStk88/sGF39TYSsK+76QuRQ8SBdvzlHS+e
CNCJMIhZUHSUCn10mo17V6MDV/lXMuajSLlxzSsKxjzxFQxswIMCtEaxFMvqokZw
pyZdsYs5aZGAaRQ0fBbCsVAR1neki5Z7hhChBFOf5DuMbU3djD6/efoqhyhscruD
Vb8r2bslL244830ZhX3yJRKiyxvKNPvquuzORIG7BHi9kucU60zMrXZ8tGC2W07+
KtPKxTc6SVe5QiPDUsi5okyM0qQJ/5oLxNaD9vOV2wCIKmfKotgC42svITDNLkvJ
6nLFYUELHQcqVHlsmwW1AoIBAQD50eyXAk4FwlBxWDO8zJush7J3pRMPndWMDoL1
5XEPCzENEz8FZoBCNCup6CSUSL8WjnOVrMyBRQgWfZhB7u2T3NBRsMLt66RCu2L5
BjZHRi6F3nuIS9Xfs7CNi9D2tcI/FT7xPe3AEgJKuGIKaySUip1Q+dAAh3XyPlco
1EPYpPJAY+FnYNStcBHLXa2v+v212GCMGB9WLhegBWt+FWjn/tMyqJifUIQy7M7k
5dCLO6kmo0VPWMngspUPcX77JtJLOA/JgeBAO91uDJMWHelPS2zIkPZb3pG8L+yz
K33Ry+YY0SUqzBLFfQmD6HWz7sivcv2aCHD0PcY8GcCQxAJNAoIBAQC8Mrl8w7vE
LMDvbiAMoK6iYJr0FbFGoiDfJhLU5MkIRRv5439qtXmF3EVFcQTsXf6km0U/YaYq
/e4b44YCjIQDiD/LJPjZThHiCyYduNl9RUeVYbAubtBK7MJ2KQxNVfG2XOYJmxg1
j5/McX5v5JA+bTdtRp0OH0OYPiA/ilM2+Gp1m/qOD85OS+Z1Np+jNQ0UXY7LYZP3
NbFdBRnil1obeZKxqOxdAuate+cioKrvHRvbHLF6GNWde9+f8q+2cfNZijyJwE6R
vURwDCwdNUaPCTtc7s9NSP2WNHaOM4pkmlu6mgZl2PLzZimUCeev8EovGH3VAMl3
i2ytNEJ+56enAoIBAQDGbZaFj6AXdPNeRBe8M6zHCnWYEPcl5VEUUQZ2eAsoTtRk
NVBOYs8nRrcT2r8LRQj6yqVGUp2RZBp7esDwRe5RDwgsisEaJ5wuIRcJA4UjcbxM
Op5WcR3s9JYcp9yPyWkDoEWBapYohGVroi7FZbsFfWBdTD+J3A60Hg4u8QL+1m1Q
9cS4zzG+nRCVPtBRwoO456gwPozNcAj14rgxyqGr/D0WtNGdYV/P70aai2vs27OM
bA0GbFjVcCNzw8t/g6NveZUYkl9jxekomzZNT+7cO+WpHXOBHzUUi+Bvo/DpLhKS
zbS+3J9gW+Ot8XtkMxsWOLj0mxXU+ig13qKUmgvVAoIBAB2k08jOP/5HmmBcdVnn
2XokQ2QdIp5gnVLo+WBlZTETSbPT3NcfHLQ0HQkyIzdkGt8swfyY0gbFlsL31L0E
CytPQ9UozrXT8UcswGVAH6n2xq7GA21c8RxMLNlV3+Uym29BNM7gijCtndsjKWpQ
k1Px+iARVl3KGOibKJM5o5/uAz7hQdcssC9vDy75Wq3nhlbl4b8xcJAo+fYP/qLN
elkHjk7Dr+96rIE5GhA/RI2DhUa/P0lfLg6vW2sjXAAd9Nnux1hfXUDhki0gDbbQ
FHwlVR9vUmH3FFKbku0VO0BbfAVpi4ZxZNtoBTaXVNJGxDik3/U0OYfGA2lI6Qx6
StMCggEAV1XytpdVbCAlPitA5mkncFXXW6YhRufmkmzbYeTboPzYlNz9F2xmYjIo
xNfzwiGepHyG38YdgNJ/h1NNo4a7JCLKRPReRca1V+td9BP7ZKAQEHAtAY6QwHJ1
aJzZxmcohMWh9LXmUzeSnSIMbG/JNqIwy6W6EMmzC5eXL9FHaWCr3WQs05wE+CJF
pJkXbmXkg+rbct9hAYKVw7zQjezTbfRPqcHdsHVOJBZCTbCSm44XWnLuu90jQ2Ku
pTOTmM3h0mKOG8tVTaibJdeNHzk0+SDhUdOI5ORA0Q+iHZaEbPO39/c+sr0n9xLF
17M9lCizO9o9dONdHsHfNQi6y9Jcnw==
-----END PRIVATE KEY-----`;

const pemEncodedCrt = `-----BEGIN CERTIFICATE-----
MIIEtTCCAp2gAwIBAgIUDyuccmylba71lZQAQic5TJiAhwwwDQYJKoZIhvcNAQEL
BQAwGDEWMBQGA1UEAwwNSmV0UHJvZmlsZSBDQTAeFw0yMzA5MjkxNDA2MTJaFw0z
MzA5MjcxNDA2MTJaMBExDzANBgNVBAMMBk5vdmljZTCCAiIwDQYJKoZIhvcNAQEB
BQADggIPADCCAgoCggIBALenqcGP2ZxGkYqmKA9c4Hzf8+YD1smvmOxKjd+bmTLr
utM/hXv1cj1rW3/lqyDtdDk7K6W8/TDq1CRrEt+Do6l30DxhAiC34aH8DmGwgq77
xEoLimvH5LpePxflF+tbB1RZtFgFDOIYLdSQaKFH2JDgVKxhLiV3S6jniPhkCtWW
rTs+E6vq4N15Bm3NnM5AJILqjtUbOjNfaxVq6RrOoTc0R3Fqqo6yvxo/+JYa2UnH
IC+r2dbKuDLMUrtgnydEUdJNX0zH9FtcdELvr48uc9mY038TWUsZUK1pnQbxA2bP
yA4qnYJ9IvUgO6LtLXvGFm137YQMS1N41AHDBOrwoNI8UoDX+qI3rM96biFOFvn7
Edky7rByzybt3H+zxdojfjvpL1E0NO98BT9zfufHAaAxZtlmDOu5LDJe3CGurnyR
MRExbtc+Qjl1mUh6tG4lakAwdsoxry0GdG72yaYyb9it53kaFks/T/s7Z7bRJzVF
zQDV1Y4bzUtk43vKm2vztBVlQkBkZY5f2Jbe5Ig3b8swQzBnOT0mrL5SPUhwmQ6I
xkEWztj55OEujBMmRr92oESuq9ZYMaeLidKWVR3/++HA8BRZaRGEKtSHZCbFEFdi
hDxxJv9Xh6NuT/ewJ6HYp+0NQpFnUnJ72n8wV+tudpam7aKcdzVmz7cNwOhG2Ls7
AgMBAAEwDQYJKoZIhvcNAQELBQADggIBAIdeaQfKni7tXtcywC3zJvGzaaj242pS
WB1y40HW8jub0uHjTLsBPX27iA/5rb+rNXtUWX/f2K+DU4IgaIiiHhkDrMsw7piv
azqwA9h7/uA0A5nepmTYf/HY4W6P2stbeqInNsFRZXS7Jg4Q5LgEtHKo/H8USjtV
w9apmE3BCElkXRuelXMsSllpR/JEVv/8NPLmnHSY02q4KMVW2ozXtaAxSYQmZswy
P1YnBcnRukoI4igobpcKQXwGoQCIUlec8LbFXYM9V2eNCwgABqd4r67m7QJq31Y/
1TJysQdMH+hoPFy9rqNCxSq3ptpuzcYAk6qVf58PrrYH/6bHwiYPAayvvdzNPOhM
9OCwomfcazhK3y7HyS8aBLntTQYFf7vYzZxPMDybYTvJM+ClCNnVD7Q9fttIJ6eM
XFsXb8YK1uGNjQW8Y4WHk1MCHuD9ZumWu/CtAhBn6tllTQWwNMaPOQvKf1kr1Kt5
etrONY+B6O+Oi75SZbDuGz7PIF9nMPy4WB/8XgKdVFtKJ7/zLIPHgY8IKgbx/VTz
6uBhYo8wOf3xzzweMnn06UcfV3JGNvtMuV4vlkZNNxXeifsgzHugCvJX0nybhfBh
fIqVyfK6t0eKJqrvp54XFEtJGR+lf3pBfTdcOI6QFEPKGZKoQz8Ck+BC/WBDtbjc
/uYKczZ8DKZu
-----END CERTIFICATE-----`;

const array_codes = [{
	"code":"ALL",
	"name":"All Products Pack",
	"en_text":"All JetBrains Apps and Plugins",
	"ch_text":"所有 JetBrains 应用程序和插件"
},{
	"code":"DB,PDB,PSI,PCWMP",
	"name":"DataGrip",
	"en_text":"The IDE for databases and SQL",
	"ch_text":"用于数据库和 SQL 的 IDE"
},{
	"code":"PS,PDB,PSI,PCWMP",
	"name":"PhpStorm",
	"en_text":"A smart IDE for PHP and Web",
	"ch_text":"适用于 PHP 和 Web 的智能 IDE"
},{
	"code":"YTD,PDB,PSI,PCWMP",
	"name":"YouTrack",
	"en_text":"Issue tracker designed for development teams",
	"ch_text":"专为开发团队设计的问题跟踪器"
},{
	"code":"DM,PDB,PSI,PCWMP",
	"name":"dotMemory",
	"en_text":".NET memory profiler",
	"ch_text":".NET 内存分析器"
},{
	"code":"CWME,PDB,PSI,PCWMP",
	"name":"Code With Me Lobby",
	"en_text":"Lobby Server for Code With Me",
	"ch_text":"Code With Me 的 Lobby Server"
},{
	"code":"DP,PDB,PSI,PCWMP",
	"name":"dotTrace",
	"en_text":".NET performance profiler",
	"ch_text":".NET 性能探查器"
},{
	"code":"DS,PDB,PSI,PCWMP",
	"name":"DataSpell",
	"en_text":"The IDE for data analysis",
	"ch_text":"用于数据分析的 IDE"
},{
	"code":"QA,PDB,PSI,PCWMP",
	"name":"Aqua",
	"en_text":"A powerful IDE for test automation",
	"ch_text":"用于测试自动化的强大 IDE"
},{
	"code":"RDCPPP,PDB,PSI,PCWMP",
	"name":"Rider for Unreal Engine",
	"en_text":"Smart C++ and Blueprints support to craft the best games",
	"ch_text":"智能 C++ 和蓝图支持打造最佳游戏"
},{
	"code":"US,PDB,PSI,PCWMP",
	"name":"Upsource",
	"en_text":"Code review and repository browsing",
	"ch_text":"代码审查和存储库浏览"
},{
	"code":"AC,PDB,PSI,PCWMP",
	"name":"AppCode",
	"en_text":"A smart IDE for iOS and macOS",
	"ch_text":"适用于 iOS 和 macOS 的智能 IDE"
},{
	"code":"RC,PDB,PSI,PCWMP",
	"name":"ReSharper C++",
	"en_text":"Visual Studio extension for C++ developers",
	"ch_text":"面向 C++ 开发人员的 Visual Studio 扩展"
},{
	"code":"RD,PDB,PSI,PCWMP",
	"name":"Rider",
	"en_text":"A cross-platform .NET IDE",
	"ch_text":"跨平台的 .NET IDE"
},{
	"code":"II,PDB,PSI,PCWMP",
	"name":"IntelliJ IDEA Ultimate",
	"en_text":"The Leading Java and Kotlin IDE",
	"ch_text":"领先的 Java 和 Kotlin IDE"
},{
	"code":"RSU,PDB,PSI,PCWMP",
	"name":"ReSharper Tools",
	"en_text":"All individual .NET tools combined in one license",
	"ch_text":"所有单独的 .NET 工具合并到一个许可证中"
},{
	"code":"TCC0,PDB,PSI,PCWMP",
	"name":"TeamCity Cloud",
	"en_text":"Powerful Continuous Integration out of the box",
	"ch_text":"开箱即用的强大持续集成"
},{
	"code":"RM,PDB,PSI,PCWMP",
	"name":"RubyMine",
	"en_text":"A Ruby and Rails IDE",
	"ch_text":"Ruby 和 Rails IDE"
},{
	"code":"PC,PDB,PSI,PCWMP",
	"name":"PyCharm Professional Edition",
	"en_text":"The full-stack Python IDE",
	"ch_text":"全栈 Python IDE"
},{
	"code":"RR,PDB,PSI,PCWMP",
	"name":"RustRover",
	"en_text":"A powerful IDE for Rust",
	"ch_text":"强大的 Rust IDE"
},{
	"code":"RS0,PDB,PSI,PCWMP",
	"name":"ReSharper",
	"en_text":"Visual Studio extensions",
	"ch_text":"Visual Studio 扩展"
},{
	"code":"FL,PDB,PSI,PCWMP",
	"name":"Fleet",
	"en_text":"More Than a Code Editor",
	"ch_text":"不仅仅是代码编辑器"
},{
	"code":"WS,PDB,PSI,PCWMP",
	"name":"WebStorm",
	"en_text":"A JavaScript and TypeScript IDE",
	"ch_text":"JavaScript 和 TypeScript IDE"
},{
	"code":"GO,PDB,PSI,PCWMP",
	"name":"GoLand",
	"en_text":"An IDE for Go and Web",
	"ch_text":"适用于 Go 和 Web 的 IDE"
},{
	"code":"CL,PDB,PSI,PCWMP",
	"name":"CLion",
	"en_text":"A cross-platform C and C++ IDE",
	"ch_text":"跨平台的 C 和 C++ IDE"
},{
	"code":"TC,PDB,PSI,PCWMP",
	"name":"TeamCity",
	"en_text":"Powerful Continuous Integration out of the box",
	"ch_text":"开箱即用的强大持续集成"
},{
	"code":"DC,PDB,PSI,PCWMP",
	"name":"dotCover",
	"en_text":".NET unit test runner and code coverage tool",
	"ch_text":".NET 单元测试运行程序和代码覆盖率工具"
},{
	"code":"PRAINBOWBRACKET",
	"name":"Rainbow Brackets",
	"en_text":"🌈Rainbow Brackets for IntelliJ based IDEs/Android Studio/HUAWEI DevEco Studio Core Features Rainbowify various types brackets(Round,Squiggly,Square,Angle) Rainbowify...",
	"ch_text":"🌈Rainbow 支架适用于基于 IntelliJ 的 IDE/Android Studio/HUAWEI DevEco Studio 核心功能 Rainbowify 各种类型的支架（圆形、波浪线、方形、角度） Rainbowify..."
},{
	"code":"PSYMFONYPLUGIN",
	"name":"Symfony Support",
	"en_text":"Support for Symfony framework / components. Project Page / Documentation | Donate | Buy License Freemium All features which are inside GitHub are free to use, unless...",
	"ch_text":"支持 Symfony 框架 / 组件。项目页面 / 文档 |捐款 |购买 许可证 免费增值 GitHub 中的所有功能都可以免费使用，除非......"
},{
	"code":"PGITTOOLBOX",
	"name":"GitToolBox",
	"en_text":"Extends Git Integration with additional features Free features number of ahead, behind commits in project view and status bar number of not commited changes in project...",
	"ch_text":"通过附加功能扩展 Git 集成 免费功能 项目视图中的 ahead、behind 提交数量和状态栏 项目中未提交的更改数量..."
},{
	"code":"PMATERIALUI",
	"name":"Material Theme UI",
	"en_text":"Material Theme UI Plugin Material Design Experience for JetBrains IDEs Material Theme UI is a plugin for JetBrains IDE (IntelliJ IDEA, WebStorm, Android Studio and so...",
	"ch_text":"Material Theme UI 插件 JetBrains IDE 的材料设计体验 Material Theme UI 是 JetBrains IDE 的插件（IntelliJ IDEA、WebStorm、Android Studio 等......"
},{
	"code":"PLARAVEL",
	"name":"Laravel Idea",
	"en_text":"Laravel framework support plugin. Video tutorial | Documentation Features: Powerful code generations Advanced routing, validation, request fields, gates &amp;amp...",
	"ch_text":"Laravel 框架支持插件。视频教程 |文档功能： 强大的代码生成 高级路由、验证、请求字段、门 &amp; ..."
},{
	"code":"PBASHSUPPORTPRO",
	"name":"BashSupport Pro",
	"en_text":"BashSupport Pro is an IDE for advanced Bash, POSIX and Zsh script development – debugger, test runner, powerful editor, refactorings, ShellCheck, shfmt and more.manual...",
	"ch_text":"BashSupport Pro 是一个用于高级 Bash、POSIX 和 Zsh 脚本开发的 IDE – 调试器、测试运行器、强大的编辑器、重构、ShellCheck、shfmt 等。"
},{
	"code":"GZL",
	"name":"Grazie Pro",
	"en_text":"Enhances the bundled Grazie Lite plugin with advanced natural language writing assistance in your IDE. Grazie Pro is a result of the latest developments in deep...",
	"ch_text":"在 IDE 中通过高级自然语言编写辅助增强捆绑的 Grazie Lite 插件。Grazie Pro 是深层发展的结果......"
},{
	"code":"PBETTERHIGHLIGH",
	"name":"Better Highlights",
	"en_text":"Features: Colorize comments. Reference source code in comments. Show cognitive complexity for methods. Use gutter icons for highlights. Highlight regions (whole line...",
	"ch_text":"功能： 为评论着色。在注释中引用源代码。显示方法的认知复杂性。使用装订线图标进行高亮显示。高亮区域 （整行..."
},{
	"code":"PGERRYTHEMESPRO",
	"name":"Gerry Themes Pro",
	"en_text":"Gerry Themes Pro is a refined themes collection including 50 themes designed for comfortable development experience. Basic features in Gerry Themes &amp;amp; Gerry Themes...",
	"ch_text":"Gerry Themes Pro 是一个精致的主题集合，包括 50 个主题，旨在提供舒适的开发体验。Gerry主题和Gerry主题的基本功能..."
},{
	"code":"PFASTREQUEST",
	"name":"Fast Request – API Buddy",
	"en_text":"Restful Fast Request is an IntelliJ IDEA plugin similar to Postman that helps developers debug APIs efficiently. It is a powerful http client plugin which helps you...",
	"ch_text":"Restful Fast Request 是一个类似于 Postman 的 IntelliJ IDEA 插件，可帮助开发人员高效调试 API。它是一个功能强大的 http 客户端插件，可帮助您..."
},{
	"code":"PGHACTNSMGRPRO",
	"name":"GitHub Actions Manager",
	"en_text":"This plugin creates a tool-window on JetBrains products (IntelliJ, PyCharm, ...) where you can view GitHub Actions workflow-runs of the repository. This plugin is a...",
	"ch_text":"此插件在 JetBrains 产品（IntelliJ、PyCharm 等）上创建一个工具窗口，您可以在其中查看存储库的 GitHub Actions 工作流运行。这个插件是一个..."
},{
	"code":"PIMAGEVIEWER",
	"name":"Debug Image Viewer (former OpenCV Image Viewer)",
	"en_text":"Numpy | OpenCV | Pillow | PyTorch | TensorFlow The plugin displays an image without stopping the debugger. The basic (free) version allows working on OpenCV Images...",
	"ch_text":"麻木 |OpenCV |枕头 |PyTorch 端口 |TensorFlow 该插件在不停止调试器的情况下显示图像。基本（免费）版本允许处理 OpenCV 图像......"
},{
	"code":"AIP",
	"name":"JetBrains AI Assistant",
	"en_text":"Accelerate your whole development cycle with AI-driven features integrated into your favorite JetBrains IDE. JetBrains AI Assistant connects your IDE to third-party...",
	"ch_text":"通过将 AI 驱动型功能集成到您最喜欢的 JetBrains IDE 中，加快您的整个开发周期。JetBrains AI Assistant 将您的 IDE 连接到第三方..."
},{
	"code":"PRR",
	"name":"Rust",
	"en_text":"This plugin adds the power of RustRover, a dedicated JetBrains IDE for Rust developers, to IntelliJ IDEA Ultimate and CLion. It’s included in the Student Pack, All...",
	"ch_text":"此插件将 RustRover（面向 Rust 开发人员的专用 JetBrains IDE）的强大功能添加到 IntelliJ IDEA Ultimate 和 CLion 中。它包含在 Student Pack 中，所有..."
},{
	"code":"PAZD",
	"name":"Azd",
	"en_text":"Based on Jetbrains GitHub/GitLab plugins, AZD will streamline your development with Azure Devops. 🚀 AZD plugin integrates with both Azure DevOps Service and Azure...",
	"ch_text":"AZD 基于 Jetbrains GitHub/GitLab 插件，将使用 Azure DevOps 简化您的开发。🚀 AZD 插件与 Azure DevOps 服务和 Azure 集成..."
},{
	"code":"PANSIHIGHLIGHT",
	"name":"ansi-highlighter-premium",
	"en_text":"5 USD per year - Try it before you buy it ANSI Highlighter Premium enables the fast rendering of ANSI control-code sequences in log files, regardless their size, from...",
	"ch_text":"每年 5 美元 - 先试后买 ANSI Highlighter Premium 可以在日志文件中快速呈现 ANSI 控制代码序列，无论它们的大小如何，都可以从..."
},{
	"code":"PEXTRAICONS",
	"name":"Extra Icons",
	"en_text":"Make your IDE more pleasant to use: Adds 500+ icons for files like Travis YML, GitLab YML, Angular files, etc. Many icons have variants, so if you are not happy with...",
	"ch_text":"让您的 IDE 使用起来更舒适：为 Travis YML、GitLab YML、Angular 文件等文件添加 500+ 图标。许多图标都有变体，所以如果你对..."
},{
	"code":"PEXTRATOOLWINDO",
	"name":"Extra ToolWindow Colorful Icons",
	"en_text":"Makes tool window icons colorful. This plugin is based on the ToolWindow Colorful Icons plugin and adds new icons. You can also choose icons to (de)activate: see...",
	"ch_text":"使工具窗口图标丰富多彩。此插件基于 ToolWindow Colorful Icons 插件并添加了新图标。您还可以选择要（取消）激活的图标：请参阅..."
},{
	"code":"PSPRINGBOOTIDEA",
	"name":"Spring Boot Helper",
	"en_text":"Assist in Spring application development - Adds support for start initializr, autocomplete Spring Boot/Cloud configuration key/value, Spring reference configuration...",
	"ch_text":"协助 Spring 应用程序开发 - 添加对 start initializr、自动完成 Spring Boot/Cloud 配置键/值、Spring 引用配置..."
},{
	"code":"PSEQUENCEDIAGRA",
	"name":"SequenceDiagram Core",
	"en_text":"SequenceDiagram is tool to generate simple sequence diagram(UML) from java, kotlin, scala(Beta) code. Note : Starting from version 4.x, SequenceDiagram has been...",
	"ch_text":"SequenceDiagram 是从 java、kotlin、scala（Beta） 代码生成简单序列图 （UML） 的工具。注意：从版本 4.x 开始，SequenceDiagram 已..."
},{
	"code":"PHYBRISCOMMERCE",
	"name":"Hybris Integration",
	"en_text":"This is a plugin for SAP Hybris Commerce integration. If you have any questions or issues, please email us at support@hybris-integration.atlassian.net or use our...",
	"ch_text":"这是 SAP Hybris Commerce 集成的插件。如果您有任何问题或问题，请发送电子邮件至 support@hybris-integration.atlassian.net 或使用我们的..."
},{
	"code":"PMYBATISLOG",
	"name":"MyBatis Log",
	"en_text":"Restore mybatis/ibatis sql log to original whole executable sql. Plugin generate sql statements with replace ? to the really param value. Select the console sql log...",
	"ch_text":"将 mybatis/ibatis sql 日志恢复到原始的整个可执行 sql。插件使用 replace 生成 sql 语句 ？设置为 REAL Param 值。选择控制台 sql log..."
},{
	"code":"PRNCONSOLE",
	"name":"React Native Console",
	"en_text":"React Native Console (RN助手) A fully customizable IDEA / WebStorm / Android Studio Plugin for run React Native commands and make RN coding easier. For the full list of...",
	"ch_text":"React Native Console （RN助手） 一个完全可定制的 IDEA / WebStorm / Android Studio 插件，用于运行 React Native 命令并使 RN 编码更容易。有关..."
},{
	"code":"PMYBATISHELPER",
	"name":"MyBatisCodeHelperPro (Marketplace Edition)",
	"en_text":"MyBatisCodeHelperPro plugin for java mybatis framework, provide auto completion inspection, code generation, make mybatis easy to use GitHub |Issues |BiliBili...",
	"ch_text":"MyBatisCodeHelperPro 插件 for java mybatis 框架，提供自动补全检查、代码生成，让 mybatis 好用 GitHub |期刊 |哔哩哔哩"
},{
	"code":"PODOO",
	"name":"Odoo",
	"en_text":"Odoo Framework Integration for PyCharm Boost your productivity and make your life easier as an Odoo developer Homepage | Documentation | Issue Tracker Thank you...",
	"ch_text":"适用于 PyCharm 的 Odoo 框架集成 作为 Odoo 开发人员，提高您的工作效率，让您的生活更轻松 主页 |文档 |问题跟踪器 谢谢..."
},{
	"code":"PGITLAB",
	"name":"GitLab Integration Pro (ex-GitLab Merge Requests)",
	"en_text":"The plugin offers integration with GitLab. It works with both GitLab SaaS and GitLab Self-Managed (12.x or later). Basic features: Review merge requests right in your...",
	"ch_text":"该插件提供与 GitLab 的集成。它适用于 GitLab SaaS 和 GitLab Self-Management（12.x 或更高版本）。基本功能：直接在您的应用程序中查看合并请求..."
},{
	"code":"PCREVIEW",
	"name":"Bitbucket Integration (ex-Bitbucket Pull Requests)",
	"en_text":"The plugin offers integration with Atlassian Bitbucket. It works with both Bitbucket Cloud and Bitbucket Data Center (6.x or later). Basic features: Review pull...",
	"ch_text":"该插件提供与 Atlassian Bitbucket 的集成。它适用于 Bitbucket Cloud 和 Bitbucket Data Center（6.x 或更高版本）。基本功能：审核拉取"
},{
	"code":"PWLANG",
	"name":"Wolfram Language",
	"en_text":"A plugin for Wolfram Language development. This plugin turns IntelliJ platform based products into powerful coding environments for the Wolfram Language. It provides...",
	"ch_text":"用于 Wolfram 语言开发的插件。该插件将基于 IntelliJ 平台的产品转变为强大的 Wolfram 语言编码环境。它提供..."
},{
	"code":"PAEM",
	"name":"AEM Support",
	"en_text":"Plugin that makes development for Adobe Experience Manager (AEM) platform easier, faster and safer. Documentation Check the Documentation section for a Getting Started...",
	"ch_text":"该插件使 Adobe Experience Manager （AEM） 平台的开发更轻松、更快速、更安全。文档 查看 文档 部分以获取入门..."
},{
	"code":"PJETFORCER",
	"name":"JetForcer | The Smartest Force.com IDE",
	"en_text":"JetForcer is the smartest Force.com IDE for handy Salesforce development with JetBrains IDEs. To be more precise, JetForcer is a plugin that should be installed in any...",
	"ch_text":"JetForcer 是最智能的 Force.com IDE，可使用 JetBrains IDE 轻松进行 Salesforce 开发。更准确地说，JetForcer 是一个应该安装在任何..."
},{
	"code":"PFLYINSKYZJBZ",
	"name":"spring-assistant-@valueToYml",
	"en_text":"spring-assistant-@valueToYml spring assistant, (ctrl + left mouse) on the annotation(org.springframework.beans.factory.annotation.Value) will to yml It is advanced...",
	"ch_text":"spring-assistant-@valueToYml spring assistant，（ctrl + 鼠标左键）上的注解（org.springframework.beans.factory.annotation.Value）将 yml 高级化..."
},{
	"code":"PCWMP",
	"name":"Code With Me",
	"en_text":"Code With Me is a new solution for collaborative development and pair programming. It enables developers to share the project they have open in their IDEs with their...",
	"ch_text":"Code With Me 是一种用于协作开发和结对编程的新解决方案。它使开发人员能够将他们在 IDE 中打开的项目与他们的应用程序共享。"
},{
	"code":"PKSEXPLORER",
	"name":"KS-Explorer",
	"en_text":"Provides support for viewing keystore details. Core functionality was taken from keystore-explorer. Important: Next version will have a price 5 USD Individual price or...",
	"ch_text":"支持查看密钥库详细信息。核心功能取自 keystore-explorer。重要提示：下一个版本的价格为 5 美元 个人价格或..."
},{
	"code":"PREDIS",
	"name":"Redis",
	"en_text":"The plugin is forked from https://github.com/dboissier/nosql4idea mainly focus on support for redis Support redis cluster Support add key value and delete key value...",
	"ch_text":"该插件是从 https://github.com/dboissier/nosql4idea 分叉而来的，主要集中在对 redis 的支持上 支持 redis 集群 支持 add key value 和 delete key value..."
},{
	"code":"PDYNAMODB",
	"name":"DynamoDB",
	"en_text":"DynamoDB Plugin provides integration with local or AWS DynamoDB. It allows to browse and edit tables, run queries, export and import data and more. Features: Connect...",
	"ch_text":"DynamoDB 插件提供与本地或 AWS DynamoDB 的集成。它允许浏览和编辑表格、运行查询、导出和导入数据等等。特点： 连接..."
},{
	"code":"PELASTICSEARCH",
	"name":"Elasticsearch",
	"en_text":"Elasticsearch Plugin allows you to connect to Elasticsearch, OpenSearch or Kibana, browse and edit your data and perform REST API requests. Features: Connect to...",
	"ch_text":"Elasticsearch 插件允许您连接到 Elasticsearch、OpenSearch 或 Kibana，浏览和编辑数据，以及执行 REST API 请求。特点： 连接到..."
},{
	"code":"PAEMIDE",
	"name":"AEM IDE",
	"en_text":"Advanced support for Adobe Experience Manager application development workflows. Key Features Instantly push and pull content between projects and AEM servers.Robust...",
	"ch_text":"对 Adobe Experience Manager 应用程序开发工作流程的高级支持。主要功能 在项目和 AEM 服务器之间即时推送和拉取内容。强大的。。。"
},{
	"code":"PVISUALGC",
	"name":"JDK VisualGC",
	"en_text":"A realtime Visual Garbage Collection Monitoring Tool for local or remote running Hotspot JVM, supports G1 and ZGC This plugin displayed a Visual GC tool window in your...",
	"ch_text":"一个实时可视化垃圾收集监控工具，适用于本地或远程运行 Hotspot JVM，支持 G1 和 ZGC 此插件在您的浏览器中显示了一个可视化 GC 工具窗口。"
},{
	"code":"PMBCODEHELPPRO",
	"name":"Mybatis Smart Code Help Pro",
	"en_text":"GitHub|Documentation |qqGroup:777347929 Mybatis Smart Code Help Pro is a mybatis auxiliary plug-in You can use this plugin as a database tool without any problems...",
	"ch_text":"GitHub|文档中心 |qqGroup：777347929 Mybatis Smart Code Help Pro 是一个 mybatis 辅助插件 你可以把这个插件当作数据库工具使用，没有任何问题......"
},{
	"code":"PTOOLSET",
	"name":"Toolset",
	"en_text":"Toolset plugin is a powerful and versatile set of tools designed to enhance the development experience for software engineers. Convert Bytes: Convert Bytes to...",
	"ch_text":"Toolset 插件是一组功能强大且用途广泛的工具，旨在增强软件工程师的开发体验。转换字节：将字节转换为..."
},{
	"code":"PFIREHIGHLIGHT",
	"name":"Firebase Rules",
	"en_text":"Provides support for the Firebase rules language. Firebase Rules Features: Syntax highlighting Syntax checking Basic code completion Code formatting Code navigation...",
	"ch_text":"提供对 Firebase 规则语言的支持。Firebase 规则功能： 语法高亮显示 语法检查 基本代码完成 代码格式化 代码导航..."
},{
	"code":"PRESTKIT",
	"name":"RestfulBox - API",
	"en_text":"Github | Gitee | Perpetual license - 永久许可证 Another powerful toolkit for restful development. API management: automatic scanning, display, searching, navigation...",
	"ch_text":"Github |吉蒂 |Perpetual license - 永久许可证 另一个用于 restful 开发的强大工具包。API 管理：自动扫描、显示、搜索、导航......"
},{
	"code":"PJETCLIENT",
	"name":"JetClient - The Ultimate REST Client",
	"en_text":"JetClient is a REST (HTTP) client and API testing tool. It provides everything you need to design, test, and debug APIs effectively. With Git sync, it enables...",
	"ch_text":"JetClient 是一个 REST （HTTP） 客户端和 API 测试工具。它提供了有效设计、测试和调试 API 所需的一切。通过 Git 同步，它可以启用..."
},{
	"code":"PCODEMRBASE",
	"name":"CodeMR",
	"en_text":"CodeMR is a software quality and static code analysis tool for Java, Kotlin and Scala projects. Software systems are complex, understanding and evaluating a software...",
	"ch_text":"CodeMR 是适用于 Java、Kotlin 和 Scala 项目的软件质量和静态代码分析工具。软件系统很复杂，需要理解和评估软件..."
},{
	"code":"PISCRATCH",
	"name":"Code Note : Project Notes, Visual Markdown Editor",
	"en_text":"The most advanced Code Notes tool for Jetbrains IDEs plus a Visual Markdown editor. Allows adding code notes/bookmarks without altering the code, supports attachments...",
	"ch_text":"适用于 Jetbrains IDE 的最先进的代码说明工具以及可视化 Markdown 编辑器。允许在不更改代码的情况下添加代码注释/书签，支持附件..."
},{
	"code":"PREDISMANAGER",
	"name":"Redis Manager",
	"en_text":"Use the 30-day trial or buy it for as low as $0.5(note: click this to buy) Redis Manager 1.Support string,list,set,zset and hash data structure manager. 2.Support call...",
	"ch_text":"使用 30 天试用或以低至 0.5 美元的价格购买（注意：点击此购买） Redis 管理器 1.支持 string、list、set、zset 和 hash 数据结构管理器。2.支持呼叫..."
},{
	"code":"PWIFIADB",
	"name":"Android WiFiADB",
	"en_text":"Android Studio plugin that allows you to connect Android devices over WiFi. FREE VERSION Usage: - Please ensure your computer was configured adb in PATH. Then verify...",
	"ch_text":"Android Studio 插件，允许您通过 WiFi 连接 Android 设备。免费版使用： - 请确保您的计算机在 PATH 中配置了 adb。然后验证..."
},{
	"code":"PCMAKEPLUS",
	"name":"CMake Plus",
	"en_text":"Extend CMake language support in the IDE&#39;s Editor: - Highlighting/recognition (on top of CMake simple highlighter) of such command arguments as:   * Variable&#39;s...",
	"ch_text":"在 IDE 编辑器中扩展 CMake 语言支持： - 高亮/识别（在 CMake 简单荧光笔之上）以下命令参数： * 变量的..."
},{
	"code":"PSWIFTSUPPORT",
	"name":"Swift Support",
	"en_text":"Cross-platform Swift language support for JetBrains IDEs 2023.2 and later. discussions · bug tracker · newsletter This plugin under active development and in an early...",
	"ch_text":"JetBrains IDE 2023.2 及更高版本的跨平台 Swift 语言支持。讨论 ·错误跟踪器 ·时事通讯 这个插件正在积极开发中，处于早期..."
},{
	"code":"PEXCELEDITOR",
	"name":"ExcelEditor",
	"en_text":"English ExcelEditor is an Enhanced Edition of ExcelReader. Has all the features of ExcelReader. And additionally provides: Open multiple files (supports Excel files...",
	"ch_text":"英文 ExcelEditor 是 ExcelReader 的增强版。具有 ExcelReader 的所有功能。并且还提供：打开多个文件（支持 Excel 文件..."
},{
	"code":"PZENUML",
	"name":"ZenUML Support",
	"en_text":"This official extension integrates ZenUML directly into all JetBrains IDEs. It supports ZenUML diagram files with the extensions .z, .zen and .zenuml. The editor uses...",
	"ch_text":"此官方扩展将 ZenUML 直接集成到所有 JetBrains IDE 中。它支持扩展名为 .z、.zen 和 .zenuml 的 ZenUML 图表文件。编辑器使用..."
},{
	"code":"PCYPRESSSUPPORT",
	"name":"Cypresso",
	"en_text":"Integrates Cypress under the common Intellij test framework. Features Introduce Cypress run configuration type Debugging support. test view Navigate from test report...",
	"ch_text":"将 Cypress 集成到通用的 Intellij 测试框架下。功能 引入 Cypress 运行配置类型 调试支持。测试视图 从测试报告导航..."
},{
	"code":"PJSONTOTS",
	"name":"JsonToTypeScript",
	"en_text":"Json to TypeScript Class object generation plug-in Author: Guo Hanlin Plugin usage documentation: https://rmondjone.github.io/posts/jetbrains/jsontotypescript...",
	"ch_text":"Json 转 TypeScript 类对象生成插件 作者：郭汉林 插件使用文档：https://rmondjone.github.io/posts/jetbrains/jsontotypescript..."
},{
	"code":"PSI",
	"name":"Shared Project Indexes",
	"en_text":"The plugin reduces overall indexing time and CPU usage by using custom-built project shared indexes For more details, see the detailed instructions and documentations.",
	"ch_text":"该插件通过使用自定义构建的项目共享索引来减少总体索引时间和 CPU 使用率有关更多详细信息，请参阅详细说明和文档。"
},{
	"code":"PRDFANDSPARQL",
	"name":"RDF and SPARQL",
	"en_text":"Adds support for the RDF 1.2 (Turtle, TriG, N-Triples, N-Quads), SPARQL 1.2 and ShExC 2.1 languages as well as a bunch of productivity features. This plugin adds...",
	"ch_text":"添加了对 RDF 1.2（Turtle、TriG、N-Triples、N-Quads）、SPARQL 1.2 和 ShExC 2.1 语言的支持，以及一系列生产力功能。这个插件添加了..."
},{
	"code":"PYAOQIANGBPMN",
	"name":"Yaoqiang BPMN Editor",
	"en_text":"Yaoqiang BPMN Editor is a graphical editor for business process diagrams, compliant with OMG specifications (BPMN 2.0 / DMN 1.1).",
	"ch_text":"耀强 BPMN 编辑器是业务流程图的图形编辑器，符合 OMG 规范 （BPMN 2.0 / DMN 1.1）。"
},{
	"code":"POLYBPMNGDNEXT",
	"name":"PolyBPMN visualizer",
	"en_text":"PolyBPMN plugin for IntelliJ IDEA is a visualiser for BPMN diagrams with navigation and process debugging support. It supports editing and visualising BPMN diagrams...",
	"ch_text":"适用于 IntelliJ IDEA 的 PolyBPMN 插件是 BPMN 图的可视化工具，具有导航和流程调试支持。它支持编辑和可视化 BPMN 图表......"
},{
	"code":"PORCHIDE",
	"name":"OrchidE - Ansible Language Support",
	"en_text":"OrchidE provides language support for Ansible® playbooks, roles and variables. Code assistant for Ansible modules and keywords (syntax highlighting, code completion...",
	"ch_text":"OrchidE 为 Ansible® playbook、角色和变量提供语言支持。Ansible 模块和关键字的代码助手（语法高亮、代码完成..."
},{
	"code":"PGITLABMASTER",
	"name":"GitLab Master",
	"en_text":"Intellij-based GitLab Master This plug-in can help you better use Gitlab in Intellij IDEA, greatly simplifying the operation of Gitlab, For example, submitting merge...",
	"ch_text":"基于 Intellij 的 GitLab Master 这个插件可以帮助你更好地在 Intellij IDEA 中使用 Gitlab，大大简化了 Gitlab 的作，比如提交合并..."
},{
	"code":"PSQLFORMATTER",
	"name":"SQLFormatter",
	"en_text":"This is a tool that help you to format query SQL Usage: right click the current document click the menu item &#39;Format SQL&#39; in the Popup Menu to format your current...",
	"ch_text":"这是一个帮助您格式化查询 SQL 用法的工具：右键单击当前文档，单击弹出菜单中的菜单项“格式化 SQL”以格式化您当前的..."
},{
	"code":"PNEONPRO",
	"name":"NEON Nette Support",
	"en_text":"NEON (Nette Object Notation; Neon format) is a custom configuration language similar to YAML. Coding assistance (highlighting, completion, formatting, refactorings...",
	"ch_text":"NEON（Nette 对象表示法;Neon 格式）是一种类似于 YAML 的自定义配置语言。编码辅助（高亮显示、补全、格式化、重构..."
},{
	"code":"PTERMINAL",
	"name":"Terminal Pro",
	"en_text":"A user friendly UI for Linux command line. Makes working in the bash command line easier with IntelliJ UI features like completion, highlighting, etc... Also, the...",
	"ch_text":"适用于 Linux 命令行的用户友好型 UI。使用 IntelliJ UI 功能（如完成、高亮显示等）使 bash 命令行中的工作更加轻松。此外，这..."
},{
	"code":"PNGINX",
	"name":"Nginx Configuration Pro",
	"en_text":"Adds syntax highlighting for Nginx Configuration files, Lua code support if the Lua plugin is installed, and code completion. Features Highlighting for nginx...",
	"ch_text":"为 Nginx 配置文件添加语法高亮显示、Lua 代码支持（如果安装了 Lua 插件）以及代码完成。nginx 的功能突出显示..."
},{
	"code":"POPENAPI",
	"name":"OpenAPI Editor",
	"en_text":"Easily edit OpenAPI and Swagger specification files! Based on the Swagger plugin, from the same author. The paid plugin provides the following benefits: Live...",
	"ch_text":"轻松编辑 OpenAPI 和 Swagger 规范文件！基于 Swagger 插件，来自同一作者。付费插件提供以下好处： 实时..."
},{
	"code":"PAWSLAMBDADEPLR",
	"name":"AWS Lambda Deployer",
	"en_text":"This plugin helps in deploying the AWS Lambda function and layers build right from the JetBrains IDE. Supports deployment of AWS lambda functions. Supports management...",
	"ch_text":"此插件有助于部署 AWS Lambda 函数，并直接从 JetBrains IDE 构建层。支持部署 AWS lambda 函数。支持管理..."
},{
	"code":"PGITSCOPE",
	"name":"Git Scope",
	"en_text":"Create custom &quot;scopes&quot; for any target branch. Selectable in a tool window, which is called GIT SCOPE. The Current &quot;scope&quot; is displayed/available as diff in the tool...",
	"ch_text":"为任何目标分支创建自定义 “范围”。可在称为 GIT SCOPE 的工具窗口中选择。当前“范围”在工具中显示为/作为差异可用..."
},{
	"code":"PAPPLETRUNNER",
	"name":"Applet Runner",
	"en_text":"See Applet Runner Pro for features available in the pro version. Applet Runner is a plug-in that let you run applets in your favorite IDE. Advantages: Write a plugin...",
	"ch_text":"请参阅 Applet Runner Pro 了解 Pro 版中提供的功能。Applet Runner 是一个插件，可让您在自己喜欢的 IDE 中运行 Applet。优点： 编写插件..."
},{
	"code":"PJPASQL",
	"name":"JPA SQL",
	"en_text":"Restore jpa sql log to original whole executable sql. Plugin generate sql statements with replace ? to the really param value. Select the console sql log and right...",
	"ch_text":"将 jpa sql 日志还原为原始的整个可执行 sql。插件使用 replace 生成 sql 语句 ？设置为 REAL Param 值。选择控制台 sql log，然后右键单击..."
},{
	"code":"PJDCLEANREAD",
	"name":"JavaDoc Clean Read",
	"en_text":"Making JavaDoc comments more readable by: Hiding(folding) HTML tags; Unescape HTML escaped chars; Text styles for value of tags: &amp;lt;code&amp;gt; | &amp;lt;tt&amp;gt; | &amp;lt;li&amp;gt...",
	"ch_text":"通过以下方式使 JavaDoc 注释更具可读性：隐藏（折叠）HTML 标记;取消转义 HTML 转义字符;标记值的文本样式：&amp;lt;code&amp;gt; |&amp;lt;tt&amp;gt; |&amp;lt;li&gt;..."
},{
	"code":"PDBDATABASETOOL",
	"name":"Database Tool",
	"en_text":"issue Database Tool is a database plugin Supported database types Mysql Oracle Sqlite Mongo(2023.1.0+) Postgresql(2023.1.0+) Redis(2023.1.1+) Microsoft SQL...",
	"ch_text":"issue 数据库工具是一个数据库插件 支持的数据库类型 Mysql Oracle Sqlite Mongo（2023.1.0+） Postgresql（2023.1.0+） Redis（2023.1.1+） Microsoft SQL..."
},{
	"code":"PSFCC",
	"name":"Salesforce B2C Commerce (SFCC)",
	"en_text":"Documentation | Issue Tracker | Blog | LinkedIn 👨‍💻Support - Intellij SFCC Slack - best way to get instant support and be part of Intellij SFCC Community - Support...",
	"ch_text":"文档 |问题跟踪器 |博客 |👨 💻LinkedIn 支持 - Intellij SFCC Slack - 获得即时支持并成为 Intellij SFCC 社区一员的最佳方式 - 支持..."
},{
	"code":"PVLOG",
	"name":"SystemVerilog",
	"en_text":"SystemVerilog - including macro support Code completion, navigation, formatting, structure view, variable rename, parameter hinting and more.",
	"ch_text":"SystemVerilog - 包括宏支持代码完成、导航、格式设置、结构视图、变量重命名、参数提示等。"
},{
	"code":"PLEP",
	"name":"LeetCode Editor Pro",
	"en_text":"Support for leetcode.com and leetcode.cn, can test and submit questions. More tutorial please visit： here Introduction Support for leetcode.com and leetcode.cn, can...",
	"ch_text":"支持 leetcode.com 和 leetcode.cn，可以测试和提交问题。更多教程请访问：这里介绍 支持 leetcode.com 和 leetcode.cn，可以..."
},{
	"code":"PJMETERVIEWER",
	"name":"JMeter Viewer",
	"en_text":"Provides support to view jmeter test plans. Features: JMeter test plan Viewer.",
	"ch_text":"支持查看 jmeter 测试计划。功能： JMeter 测试计划查看器。"
},{
	"code":"PGITWORKTREE",
	"name":"Git Worktree",
	"en_text":"Take advantage of Git worktrees right inside your IDE Free features view worktrees create worktree from HEAD or branch open worktree Paid features add worktree from...",
	"ch_text":"在您的 IDE 中利用 Git 工作树 免费功能 查看工作树 从 HEAD 创建工作树或分支打开工作树 付费功能从..."
},{
	"code":"PDATAGRAPH",
	"name":"DataGraph",
	"en_text":"The DataGraph plugin visualizes JSON, YAML, and XML in interactive graphs, providing a powerful tool for exploring large and complex data structures. Here&#39;s what you...",
	"ch_text":"DataGraph 插件在交互式图形中可视化 JSON、YAML 和 XML，为探索大型复杂数据结构提供了强大的工具。这是你..."
},{
	"code":"PMATERIALHC",
	"name":"Material Theme UI High Contrast",
	"en_text":"Material Theme UI High Contrast is an external plugin for the Material Theme UI plugin to provide access to the High Contrast feature. This plugin must be loaded...",
	"ch_text":"材料主题 UI 高对比度是材料主题 UI 插件的外部插件，用于提供对高对比度功能的访问。这个插件必须加载..."
},{
	"code":"PSMARTJUMP",
	"name":"Smart Jump",
	"en_text":"Smart Jump is a plugin that navigate to anywhere you want. Code Navigation: Java Method ➔ MyBatis Xml MyBatis Xml ➔ Java Method Html ➔ JS/CSS file Html ➔ JS function...",
	"ch_text":"Smart Jump 是一个插件，可以导航到您想要的任何地方。代码导航： Java 方法 ➔ MyBatis Xml MyBatis Xml ➔ Java 方法 Html ➔ JS/CSS 文件 Html ➔ JS 函数..."
},{
	"code":"PREDISCLIHELPER",
	"name":"Redis Client",
	"en_text":"Redis client connection management and data manipulation for IntelliJ IDEs. An advanced GUI client for Redis, Support Standalone, Sentinel, Cluster &amp;amp; SSH, Support...",
	"ch_text":"IntelliJ IDE 的 Redis 客户端连接管理和数据作。一个高级的 Redis 图形用户界面客户端，支持独立、哨兵、集群和 SSH，支持..."
},{
	"code":"PJFORMDESIGNER",
	"name":"JFormDesigner (Marketplace Edition)",
	"en_text":"Advanced Swing GUI designer with outstanding support for MigLayout, JGoodies FormLayout, GroupLayout (Free Design), TableLayout and GridBagLayout, which makes it easy...",
	"ch_text":"高级 Swing GUI 设计器，对 MigLayout、JGoodies FormLayout、GroupLayout（免费设计）、TableLayout 和 GridBagLayout 提供出色支持，这使其变得容易......"
},{
	"code":"PREDISTOOLS",
	"name":"Redis-Cli",
	"en_text":"This is a Redis Plugin, you can use it to CRUD Redis. Show Keys by tree view. Supporting to access Redis by SSH, ssl, Sentinel. Support STRING, SET, HASH, ZSET...",
	"ch_text":"这是一个 Redis 插件，你可以用它来 CRUD Redis。按树视图显示键。支持通过 SSH、ssl、Sentinel 访问 Redis。支持 STRING、SET、HASH、ZSET..."
},{
	"code":"PCAICOMMITAPP",
	"name":"AICommit",
	"en_text":"AI-powered programming assistant for JetBrains IDEs! Intelligent commit message writer using GPTIn-editor pop-up for AI-driven features: code optimization, code...",
	"ch_text":"适用于 JetBrains IDE 的 AI 驱动的编程助手！使用 GPTIn-editor 弹出窗口的智能提交消息编写器，用于 AI 驱动的功能：代码优化、代码..."
},{
	"code":"PNGROK",
	"name":"Ngrok",
	"en_text":"Provides support for ngrok. Important: Next version will have a price 5 USD for individual and 15 USD for business per year, to support my work How to use it? Edit...",
	"ch_text":"为 ngrok 提供支持。重要提示：下一个版本的价格为个人每年 5 美元，企业每年 15 美元，以支持我的工作如何使用它？编辑。。。"
},{
	"code":"PGITLABCI",
	"name":"Git CI Pipeline Dashboard",
	"en_text":"Gitlab CI Dashboard Manage your Gitlab pipelines from your JetBrains IDE. Features 🔐️ Use your Gitlab account from gitlab.com, self-hosted GitLab Community Edition...",
	"ch_text":"Gitlab CI 仪表板 从 JetBrains IDE 管理您的 Gitlab 管道。功能 🔐️ 使用来自 gitlab.com、自托管 GitLab 社区版的 Gitlab 帐户..."
},{
	"code":"PTAILWINDFOLD",
	"name":"Tailwind Fold",
	"en_text":"Tailwind Fold We all love Tailwind CSS, but sometimes it can be a bit verbose. This plugin will help you fold the classes to make your templates more readable. Enable...",
	"ch_text":"Tailwind Fold 我们都喜欢 Tailwind CSS，但有时它可能有点冗长。此插件将帮助您折叠类以使您的模板更具可读性。使。。。"
},{
	"code":"PGITLABCICD",
	"name":"GitLab CICD - Pipelines &amp; Jobs, Builds Run Cancel Retry View Log",
	"en_text":"GitLab CICD for software developers GitLab CICD is an IDE plugin designed to make it easier for you to view and manage GitLab CI/CD directly from within the IDE. The...",
	"ch_text":"面向软件开发人员的 GitLab CICD GitLab CICD 是一个 IDE 插件，旨在让您更轻松地直接从 IDE 中查看和管理 GitLab CI/CD。这。。。"
},{
	"code":"PMAGE",
	"name":"Magento and Adobe Commerce PhpStorm by Atwix",
	"en_text":"This is a PhpStorm IDE plugin for a better Magento 2 development workflow developed by Atwix The Atwix PhpStorm Plugin for Magento and Adobe Commerce helps developers...",
	"ch_text":"这是一个 PhpStorm IDE 插件，用于更好的 Magento 2 开发工作流程，由 Atwix 开发 用于 Magento 和 Adobe Commerce 的 Atwix PhpStorm 插件可帮助开发人员..."
},{
	"code":"PBREWBUNDLE",
	"name":"Brew Bundle",
	"en_text":"Provides support for Brew bundle files. Important: Next version will have a price 1 USD per year, to support my work Features: Syntax highlighting.",
	"ch_text":"提供对 Brew 捆绑包文件的支持。重要提示：下一个版本的价格为每年 1 美元，以支持我的工作 特点：语法高亮。"
},{
	"code":"PSKOL",
	"name":"Skol",
	"en_text":"Northern lights feeling straight to your IDE. A simple but powerful dark theme that looks great and relaxes your eyes. The plugin provides the following features: Two...",
	"ch_text":"北极光感觉直接进入您的 IDE。一个简单但强大的深色主题，看起来很棒，让你的眼睛放松。该插件提供以下功能： 二..."
},{
	"code":"PPUMLSTUDIO",
	"name":"PlantUML Studio",
	"en_text":"This plugin makes conveniently utilizes PlantUML on your IntelliJ project. Features Editor supports. (ex: syntax highlighting, references, refactoring and code...",
	"ch_text":"此插件可以方便地在您的 IntelliJ 项目中使用 PlantUML。功能编辑器支持。（例如：语法高亮、引用、重构和代码..."
},{
	"code":"PSWPLUGIN",
	"name":"Shopware",
	"en_text":"Support for Shopware Version &amp;lt;= 5, 6+ and extended Symfony framework integration Issues | Donate Shopware 6+ / Symfony Integration Javascript / Administration...",
	"ch_text":"支持 Shopware 版本 &amp;lt;= 5、6+ 和扩展的 Symfony 框架集成问题 |捐赠 Shopware 6+ / Symfony 集成 Javascript / 管理..."
},{
	"code":"PGENERATORCRUD",
	"name":"Generator Crud",
	"en_text":"🌟 Generate CRUD: The Ultimate Productivity Booster This powerful tool eliminates the hassle of writing boilerplate code for your WebApp.It allows you to concentrate...",
	"ch_text":"🌟 生成 CRUD：终极生产力助推器 这个强大的工具消除了为您的 WebApp.It 编写样板代码的麻烦，让您可以专注于......"
},{
	"code":"PATOMONEDARK",
	"name":"Atom One Dark By Mayke",
	"en_text":"A carefully refined theme inspired by Atom One Dark TIPS: Fix editor scroll bars due to IDE limitations: Instructions. Install the Atom Material Icons Plugin. TIPS FOR...",
	"ch_text":"受 Atom One Dark 启发的精心改进的主题提示：由于 IDE 限制，修复编辑器滚动条：说明。安装 Atom 材质图标插件。提示"
},{
	"code":"PPHPCODESUGG",
	"name":"Auto PHP Code Suggestions",
	"en_text":"PHP Code Suggestions is a tool that you can use for generating code, just write what you want, like (Add two numbers) and you will get a function that does what you...",
	"ch_text":"PHP Code Suggestions 是一个可以用来生成代码的工具，只需编写你想要的，比如 （Add two numbers），你就会得到一个函数，它可以做你想要的。"
},{
	"code":"PREGEXTOOL",
	"name":"Regex Tool",
	"en_text":"Regular Expression Tester for IntelliJ-based IDEs. Tester Tab: Dynamically test regular expressions. Extract Tab: Extract from the original text and assemble the...",
	"ch_text":"用于基于 IntelliJ 的 IDE 的正则表达式测试器。Tester 选项卡：动态测试正则表达式。Extract 选项卡：从原始文本中提取并组合..."
},{
	"code":"PFLUTTER",
	"name":"Flutter Storm",
	"en_text":"Support for developing Flutter applications for WebStorm etc/Flutter中文版开发工具. Unofficial WebStorm /PhpStorm /GoLand /PyCharm /CLion /RubyMine plugin for developing...",
	"ch_text":"支持为 WebStorm 等开发 Flutter 应用程序/Flutter中文版开发工具。非官方的 WebStorm /PhpStorm /GoLand /PyCharm /CLion /RubyMine 插件，用于开发..."
},{
	"code":"PGERRYCYBERPUNK",
	"name":"Gerry Cyberpunk",
	"en_text":"This plugin is Cyberpunk theme from Gerry Themes Pro, allowing you to purchase specific theme with lower price. Gerry Cyberpunk(Pro): This is a high contrast theme...",
	"ch_text":"这个插件是 Gerry Themes Pro 的赛博朋克主题，允许您以较低的价格购买特定主题。Gerry Cyberpunk（Pro）：这是一个高对比度的主题......"
},{
	"code":"PUNIAPPSUPPORT",
	"name":"Uniapp Support",
	"en_text":"Provide API libraries,extra css length unit(rpx/upx), @ alias detect,built-in components, easycom detect,compile comment , route completion and navigtation , pages...",
	"ch_text":"提供 API 库、额外的 css 长度单位（rpx/upx）、@ 别名检测、内置组件、easycom 检测、编译注释、路由完成和导航、页面......"
},{
	"code":"PKAFKA",
	"name":"Kafka Client",
	"en_text":"A powerful client for Apache Kafka. It provides support for multiple clusters, allowing you to efficiently manage topics, publish and consume messages, and perform...",
	"ch_text":"适用于 Apache Kafka 的强大客户端。它为多个集群提供支持，使您能够高效地管理主题、发布和使用消息，以及执行..."
},{
	"code":"PQUARKUSHELPER",
	"name":"Quarkus Assistant",
	"en_text":"Add module in &#39;new project&#39; to create Quarkus scaffold site: https://code.quarkus.io/ 📄 Documentation.",
	"ch_text":"在 'new project' 中添加模块以创建 Quarkus 脚手架站点：https://code.quarkus.io/ 📄 Documentation。"
},{
	"code":"PSVERILOG",
	"name":"SystemVerilog Studio",
	"en_text":"This Fancy IntelliJ Platform Plugin is going to be your implementation of the brilliant ideas that you have. This specific section is a source for the plugin.xml file...",
	"ch_text":"这个花哨的 IntelliJ 平台插件将成为您拥有的绝妙想法的实现。此特定部分是 plugin.xml 文件的来源..."
},{
	"code":"PTAILWINDTOOLS",
	"name":"Snippet Toolkit for Tailwind CSS",
	"en_text":"Extra plugin for tailwind css. Snippet browser : Store your tailwind code snippets, copy and paste it everywhere Snippet browser supports icons and snippet folders...",
	"ch_text":"tailwind css 的额外插件。代码段浏览器 ： 存储您的顺风代码片段，将其复制并粘贴到任何地方 代码段浏览器支持图标和代码段文件夹......"
},{
	"code":"PPOLARISTOMCATS",
	"name":"Polaris Tomcat Server",
	"en_text":"Polaris Tomcat Server is a plugin for Intellij IDEA Community, Ultimate and Educational. Highlights: One-click to download tomcatAuto-detect maven web...",
	"ch_text":"Polaris Tomcat Server 是 Intellij IDEA Community、Ultimate 和 Education 的插件。应用亮点：一键下载 tomcatAuto-detect maven web..."
},{
	"code":"PHPEAPLUGIN",
	"name":"Php Inspections (EA Ultimate)",
	"en_text":"A commercial Code Review and Static Code Analysis tool based on Php Inspections (EA Extended). News | Support. Php Inspections (EA Ultimate) is further extending IDE...",
	"ch_text":"基于 Php Inspections （EA Extended） 的商业代码审查和静态代码分析工具。新闻 |支持。Php Inspections （EA Ultimate） 进一步扩展了 IDE..."
},{
	"code":"PEXTPACK",
	"name":"Extra Tools Pack",
	"en_text":"Extra Tools Pack provides the exact same features as Extra Icons, Extra IDE Tweaks and Extra ToolWindow Colorful Icons. This plugin pack costs $21. The included...",
	"ch_text":"Extra Tools Pack 提供与 Extra Icons、Extra IDE Tweaks 和 Extra ToolWindow Colorful Icons 完全相同的功能。这个插件包售价 21 美元。包含的..."
},{
	"code":"PKSIX",
	"name":"k6",
	"en_text":"IntelliJ-based Plugin to run k6 tests locally or in the k6 Cloud from your IntelliJ IDE. Run a k6 test as a Run configuration (a common way to run something withing...",
	"ch_text":"基于 IntelliJ 的插件，用于从 IntelliJ IDE 在本地或 k6 Cloud 中运行 k6 测试。将 k6 测试作为 Run 配置运行（一种在 ..."
},{
	"code":"PJAVACODESUGG",
	"name":"Auto Java Code Suggestions",
	"en_text":"Java Code Suggestions is a tool that you can use for generating code, just write what you want, like (Add two numbers) and you will get a function that does what you...",
	"ch_text":"Java Code Suggestions 是一个可以用来生成代码的工具，只需编写你想要的，比如 （Add two numbers），你就会得到一个函数，它可以做你想要的。"
},{
	"code":"PAICODING",
	"name":"AI Coding",
	"en_text":"AI Coding can help developers use the services of AI providers (such as OpenAI/Claude/Baidu/Google) more conveniently, improving development efficiency. FeaturesAdd a...",
	"ch_text":"AI Coding 可以帮助开发者更便捷地使用 AI 提供商（如 OpenAI/Claude/百度/Google）的服务，提高开发效率。功能添加..."
},{
	"code":"PQTSQSSEDITOR",
	"name":"Qt Style Sheets Editor",
	"en_text":"Qt Style Sheets Editor helps to work with Qt Style Sheets files. IMPORTANT: Please uninstall or deactivate Qt Style Sheet Highlighter plugin before installing Qt Style...",
	"ch_text":"Qt 样式表编辑器有助于处理 Qt 样式表文件。重要提示：在安装 Qt Style 之前，请卸载或停用 Qt Style Sheet Highlighter 插件..."
},{
	"code":"PMATERIALLANG",
	"name":"Material Theme UI Language Additions",
	"en_text":"Material Theme UI Language Additions is an external plugin for the Material Theme UI plugin, providing access to the specific features currently only available to...",
	"ch_text":"Material Theme UI Language Additions 是 Material Theme UI 插件的外部插件，提供对当前仅适用于..."
},{
	"code":"PSTORMSECTIONS",
	"name":"StormSections",
	"en_text":"Boost your Productivity with pleasure! A Productivity Plugin for JetBrains™ IDEs &amp;amp; Android Studio! Storm Sections Plugin lets you become more productive by...",
	"ch_text":"愉快地提高生产力！一个适用于JetBrains™ IDEs和Android Studio的生产力插件！Storm Sections Plugin 让您通过以下方式提高工作效率......"
},{
	"code":"PMATERIALCUSTOM",
	"name":"Material Theme UI Custom Theme",
	"en_text":"Material Theme UI Custom Theme is an external plugin for the Material Theme UI plugin, providing access to the specific features currently only available to premium...",
	"ch_text":"Material Theme UI Custom Theme 是 Material Theme UI 插件的外部插件，提供对当前只有高级用户才能使用的特定功能的访问。"
},{
	"code":"PHEROKU",
	"name":"Heroku Dashboard",
	"en_text":"Heroku Dashboard It helps you to manage your projects and releases: Features 🖥 Show activity.🛠 Manage environment variables.🔄 Restart dynos.📋 Update collaborators.",
	"ch_text":"Heroku 仪表板 它可以帮助您管理您的项目和发布： 功能 🖥 显示活动。🛠管理环境变量。🔄重新启动 dynos。📋更新协作者。"
},{
	"code":"PGOLANGCODESUGG",
	"name":"Auto GOLang Code Suggestions",
	"en_text":"GOLang Code Suggestions is a tool that you can use for generating code, just write what you want, like (Add two numbers) and you will get a function that does what you...",
	"ch_text":"GOLang Code Suggestions 是一个可以用来生成代码的工具，只需编写你想要的，比如 （Add two numbers），你就会得到一个函数，它可以做你想要的。"
},{
	"code":"PGITFLOWPLUS",
	"name":"GitFlowPlus",
	"en_text":"这是一个适用于git flow (master,release,test,feature) 流程的分支管理插件 使用指南。 最大优势是减少敏捷开发过程中切换分支和合并分支的操作，降低分支管理的人力成本。 主要解决的问题： 1. 简化日常工作中分支操作步骤，比如新建分支、提测、发布、Merge Request等操作； 2...",
	"ch_text":"这是一个适用于git flow （master，release，test，feature） 流程的分支管理插件 使用指南。最大优势是减少敏捷开发过程中切换分支和合并分支的操作，降低分支管理的人力成本。主要解决的问题： 1.简化日常工作中分支作步骤，比如新建分支、提测、发布、Merge Request等作; 2..."
},{
	"code":"PSCIPIO",
	"name":"Scipio ERP Integration",
	"en_text":"The plugin works with all versions of Scipio ERP (although ftl autocomplete is specific to latest release). OFBiz is also partially supported. Scipio ERP is a...",
	"ch_text":"该插件适用于所有版本的 Scipio ERP（尽管 ftl 自动完成特定于最新版本）。OFBiz 也部分受支持。Scipio ERP 是一个..."
},{
	"code":"POXYXSDJSONSCH",
	"name":"XSD to JSON Schema",
	"en_text":"This is a plugin for converting an XML Schema (XSD) file to a JSON Schema file. To perform a conversion, follow these steps: Once installed, go to Tools -&amp;gt; XML...",
	"ch_text":"这是一个用于将 XML 架构 （XSD） 文件转换为 JSON 架构文件的插件。要执行转换，请执行以下步骤：安装后，转到工具 - &amp;gt; XML..."
},{
	"code":"PMONGODB",
	"name":"Mongo DB",
	"en_text":"This plugin seamlessly integrates MongoDB servers with a database/collections tree structure, along with providing a Query Runner and an integrated Shell console...",
	"ch_text":"该插件将 MongoDB 服务器与数据库/集合树结构无缝集成，并提供 Query Runner 和集成的 Shell 控制台......"
},{
	"code":"PJSONNETEMLSUP",
	"name":"Jsonnet Pro",
	"en_text":"Adds support for Jsonnet -- The Data Templating Language. Jsonnet is a domain specific configuration language from Google. It is an extension of JSON. The plugin adds...",
	"ch_text":"添加对 Jsonnet （数据模板语言） 的支持。Jsonnet 是 Google 提供的一种特定于域的配置语言。它是 JSON 的扩展。该插件添加了..."
},{
	"code":"PMATERIALFRAME",
	"name":"Material Theme UI Project Frame",
	"en_text":"Material Theme UI Project Frame is an external plugin for the Material Theme UI plugin, providing access to the specific features currently only available to premium...",
	"ch_text":"Material Theme UI Project Frame 是 Material Theme UI 插件的外部插件，提供对当前只有高级用户可用的特定功能的访问。"
},{
	"code":"PAWSQLADVISOR",
	"name":"SQL Optimizer,Index Advisor MySQL/Postgre/Oracle, Tune by PawSQL",
	"en_text":"PawSQL Advisor is an automatic and intelligent SQL optimization tool for databases including MySQL, PostgreSQL, MariaDB, and Oracle, etc. It helps database application...",
	"ch_text":"PawSQL Advisor 是一款自动化、智能的 SQL 优化工具，适用于 MySQL、PostgreSQL、MariaDB 和 Oracle 等数据库。它有助于数据库应用程序..."
},{
	"code":"PGDOC",
	"name":"Generate Document",
	"en_text":"API development tool, automatically generate interface documents. GitHub Issues Demo EnglishJava code comments automatically converts user-defined template...",
	"ch_text":"API 开发工具，自动生成接口文档。GitHub Issues Demo 中文Java 代码注释自动转换用户定义的模板..."
},{
	"code":"PGERRYSPACE",
	"name":"Gerry Space",
	"en_text":"This plugin is Space theme from Gerry Themes Pro, allowing you to purchase specific theme with lower price. Gerry Space(Pro): Deep dark color themes, inspired by black...",
	"ch_text":"这个插件是 Gerry Themes Pro 的太空主题，允许您以较低的价格购买特定的主题。Gerry Space（Pro）：深深色主题，灵感来自黑色......"
},{
	"code":"PGERRYCHERRY",
	"name":"Gerry Cherry",
	"en_text":"This plugin is Cherry theme from Gerry Themes Pro, allowing you to purchase specific theme with lower price. Gerry Cherry(Pro): A dark pink tone theme, inspired by...",
	"ch_text":"这个插件是 Gerry Themes Pro 的 Cherry 主题，允许您以较低的价格购买特定的主题。Gerry Cherry（Pro）：深粉色调主题，灵感来自......"
},{
	"code":"PLOCALSTACK",
	"name":"LocalStack Integrator",
	"en_text":"LocalStack Integrator is designed to streamline the process of managing and integrating your local AWS environment, via LocalStack, directly into your IntelliJ IDE...",
	"ch_text":"LocalStack Integrator 旨在简化通过 LocalStack 管理和集成本地 AWS 环境并将其直接集成到 IntelliJ IDE 中的流程..."
},{
	"code":"PEXTENSION",
	"name":"Extensions Manager",
	"en_text":"A plugin tool window brings to you without opening the Settings &amp;gt; Plugins pane anymore, search, update and install plugins just in your main IDE window just like...",
	"ch_text":"插件工具窗口让您无需再打开“设置”&amp;gt;“插件”窗格，只需在主 IDE 窗口中搜索、更新和安装插件，就像......"
},{
	"code":"PNPMPACKAGEJSON",
	"name":"NPM Package Json",
	"en_text":"Package Json The NPM package.json plugin is a tool designed to simplify the management of your Node.js projects. Features ✍️ Dependency completion: Easily search for...",
	"ch_text":"包 JsonNPM package.json 插件是一种旨在简化 Node.js 项目管理的工具。功能 ✍️ 依赖项完成：轻松搜索..."
},{
	"code":"PBISJ",
	"name":"Java Antidecompiler",
	"en_text":"Absolute Java byte code and resources protection.",
	"ch_text":"绝对的 Java 字节码和资源保护。"
},{
	"code":"PXSDVISUALIZER",
	"name":"XSD / WSDL Visualizer",
	"en_text":"Simplify Your XML Schema Definition (XSD) and WSDL File Editing Process Attention! Please be aware of a known issue in IntelliJ that may occur when uninstalling our...",
	"ch_text":"简化 XML 架构定义 （XSD） 和 WSDL 文件编辑过程注意！请注意 IntelliJ 中的一个已知问题，该问题在卸载我们的..."
},{
	"code":"PRSMGNL",
	"name":"Magnolia YAML Assistant",
	"en_text":"The plugin significantly reduces the effort of light development in YAML with Magnolia CMS. Created for developers by developers, it automates the most time-consuming...",
	"ch_text":"该插件显著减少了使用 Magnolia CMS 在 YAML 中进行轻量级开发的工作量。它由开发人员为开发人员创建，可自动执行最耗时的..."
},{
	"code":"PYIIFRAMEWORK",
	"name":"Yii2 Framework Support",
	"en_text":"Yii2 framework support plugin. The plugin is based on Yii2-support plugin and made by one of original authors. Original plugin is not supported by modern IntelliJ...",
	"ch_text":"Yii2 框架支持插件。该插件基于 Yii2-support 插件，由原作者之一制作。现代 IntelliJ 不支持原始插件..."
},{
	"code":"PDATABASE",
	"name":"Database Helper",
	"en_text":"Database help tool, which generates corresponding data based on the information related to the database table according to the custom template. FeaturesAutomatically...",
	"ch_text":"Database help 工具，根据自定义模板，根据数据库表的相关信息生成相应的数据。功能自动..."
},{
	"code":"PCDMQTTCLIENT",
	"name":"MQTT Client",
	"en_text":"A MQTT client tool that enables you to interact quickly and easily with any MQTT Broker or IoT(Internet Of Things) Server. The client gives you a single compact tool...",
	"ch_text":"一种 MQTT 客户端工具，使您能够快速轻松地与任何 MQTT 代理或 IoT（物联网）服务器进行交互。客户端为您提供一个紧凑的工具..."
},{
	"code":"PNEKOCAT",
	"name":"TamaCat the Embedded Internet Browser",
	"en_text":"An embedded web browser for JetBrains IDEs. Pin tabs to keep websites accessible even after IDE restart, open multiple browser tool windows in a single IDE window to...",
	"ch_text":"适用于 JetBrains IDE 的嵌入式 Web 浏览器。固定选项卡以保持网站即使在 IDE 重新启动后也能访问，在单个 IDE 窗口中打开多个浏览器工具窗口以..."
},{
	"code":"PDBSSH",
	"name":"SSH Tool",
	"en_text":"SSH allows you to connect directly to remote services without leaving the development function, and continue to log in, file upload, copy and other convenient...",
	"ch_text":"SSH 让您无需离开开发功能即可直接连接到远程服务，并继续登录、文件上传、复制等便捷作。"
},{
	"code":"PJSONTOANYLANGU",
	"name":"JsonToAnyLanguage",
	"en_text":"JsonToAnyLanguage Plugin Introduction A plugin for converting json strings to any language entity, currently supported languages are...",
	"ch_text":"JsonToAnyLanguage 插件介绍 一个用于将 json 字符串转换为任何语言实体的插件，目前支持的语言是......"
},{
	"code":"PFIREBASE",
	"name":"Firebase Firestore",
	"en_text":"Firebase Firestore Plugin Integrates seamlessly with Firebase Firestore, offering an intuitive and powerful interface for managing Firestore data and executing...",
	"ch_text":"Firebase Firestore 插件与 Firebase Firestore 无缝集成，为管理 Firestore 数据和执行..."
},{
	"code":"PCIINTG",
	"name":"CIclone",
	"en_text":"Get notified when a build on GitHub Actions, Jenkins, CircleCI, AWS CodeBuild and GitLab CI/CD is finished. Jump to failed test cases, and run them locally...",
	"ch_text":"在 GitHub Actions、Jenkins、CircleCI、AWS CodeBuild 和 GitLab CI/CD 上的构建完成时收到通知。跳转到失败的测试用例，并在本地运行它们......"
},{
	"code":"PGERRYNATURE",
	"name":"Gerry Nature",
	"en_text":"This plugin is Nature theme from Gerry Themes Pro, allowing you to purchase specific theme with lower price. Gerry Nature(Pro): Eye protection background color theme...",
	"ch_text":"这个插件是 Gerry Themes Pro 的 Nature 主题，允许您以较低的价格购买特定主题。Gerry Nature（Pro）：护眼背景颜色主题..."
},{
	"code":"PVSCODEICONS",
	"name":"VSCode Icons",
	"en_text":"Using VSCode Icons in InteliJ IDEA, Make your IDE more pleasant to use. Replaced icons for specific directories: node_modules, .vscode, .git... Replaced src, main...",
	"ch_text":"在 InteliJ IDEA 中使用 VSCode 图标，让您的 IDE 使用起来更舒适。替换了特定目录的图标：node_modules、.vscode、.git...替换了 src、main..."
},{
	"code":"PGERRYAURORA",
	"name":"Gerry Aurora",
	"en_text":"This plugin is Aurora theme from Gerry Themes Pro, allowing you to purchase specific theme with lower price. Gerry Aurora(Pro): A dark blue tone theme, inspired by...",
	"ch_text":"这个插件是 Gerry Themes Pro 的 Aurora 主题，允许您以较低的价格购买特定的主题。Gerry Aurora（Pro）：深蓝色调主题，灵感来自......"
},{
	"code":"PZKA",
	"name":"Zookeeper-Admin",
	"en_text":"A simple tool allows you to administrate Zookeeper. Following features are available: 1.normal &amp;amp; ssh-tunnel zookeeper access 2.zookeeper CRUD operations 3.simple...",
	"ch_text":"一个简单的工具允许您管理 Zookeeper。以下功能可用：1.正常和ssh-tunnel zookeeper访问 2.zookeeper CRUD作 3.简单..."
},{
	"code":"PSCREENCODEPRO",
	"name":"ScreenCodePro",
	"en_text":"ScreenCodePro is a plugin that allows you to generate beautiful screenshot from your code. Simply select some code, right click on it and select &quot;Screenshot&quot; (or use...",
	"ch_text":"ScreenCodePro 是一个插件，可让您从代码中生成漂亮的屏幕截图。只需选择一些代码，右键单击它并选择“屏幕截图”（或使用..."
},{
	"code":"PIEDIS",
	"name":"Iedis 2",
	"en_text":"The Iedis 2 plugin provides Redis support in JetBrains platform. Getting Started in IDE Change Log Issue tracker Discussion.",
	"ch_text":"Iedis 2 插件在 JetBrains 平台中提供 Redis 支持。IDE 更改日志问题跟踪器讨论入门。"
},{
	"code":"PPYCODESUGG",
	"name":"Auto Python Code Suggestions",
	"en_text":"Python Code Suggestions is a tool that you can use for generating code, just write what you want, like (Add two numbers) and you will get a function that does what you...",
	"ch_text":"Python Code Suggestions 是一个可以用来生成代码的工具，只需编写你想要的，比如 （Add two numbers），你就会得到一个函数，它可以做你想要的。"
},{
	"code":"PNOSQLNAVMDB",
	"name":"NoSQL Navigator For MongoDB",
	"en_text":"NoSQL Navigator for MongoDB is an advanced plugin for JetBrains IDEs. The plugin allows to perform basic and advanced operations with MongoDB directly from your IDE...",
	"ch_text":"NoSQL Navigator for MongoDB 是 JetBrains IDE 的高级插件。该插件允许直接从您的 IDE 使用 MongoDB 执行基本和高级作......"
},{
	"code":"PREDISS",
	"name":"Redis Operator",
	"en_text":"A clean and beautiful Redis GUI client. Document. Support stand-alone, sentinel and cluster modeSTRING, LIST, SET, ZSET, HASH and STREAM typesSSH and SSLView value as...",
	"ch_text":"干净漂亮的 Redis GUI 客户端。公文。支持独立、哨兵和集群模式STRING、LIST、SET、ZSET、HASH 和 STREAM 类型SSH 和 SSL将值视为..."
},{
	"code":"PSCIPIOFTL",
	"name":"Flexible Freemarker",
	"en_text":"Personalize your Freemarker editor with Autocomplete, Documentation &amp;amp; Highlighting of all your custom Macros &amp;amp; Functions. Share your own definitions with your...",
	"ch_text":"通过自动完成、文档和高亮显示所有自定义宏和函数来个性化您的Freemarker编辑器。与您的..."
},{
	"code":"PMONGOEXPERT",
	"name":"MongoExpert",
	"en_text":"The plugin provides enhancements and extensions for MongoDB support in IntelliJ IDEs and DataGrip. Features Export collections: Export collections as JSON or binary...",
	"ch_text":"该插件为 IntelliJ IDE 和 DataGrip 中的 MongoDB 支持提供了增强和扩展。功能导出集合：将集合导出为 JSON 或二进制..."
},{
	"code":"PBEANCONVERTER",
	"name":"Simple Object Copy",
	"en_text":"The mutual transformation of DTO, VO, POJO, entity and other objects that generates the transformation code through one construction. No invasion, fast, especially...",
	"ch_text":"DTO、VO、POJO、entity 和其他对象的相互转换，通过一次构造生成转换代码。没有入侵，速度快，尤其是......"
},{
	"code":"PTLDRAI",
	"name":"TLDR",
	"en_text":"TLDR – An AI powered IDE plugin that explains code in plain english Website As developers, we spend a lot of time reading code. But what if an AI could explain the...",
	"ch_text":"TLDR – 一个 AI 驱动的 IDE 插件，可以用简单的英语解释代码 网站 作为开发人员，我们花费大量时间阅读代码。但是，如果 AI 可以解释......"
},{
	"code":"PMATERIALEXTRAS",
	"name":"Material Theme UI Extras",
	"en_text":"Material Theme UI Extras is an external plugin for the Material Theme UI plugin, providing access to the specific features currently only available to premium users...",
	"ch_text":"Material Theme UI Extras 是 Material Theme UI 插件的外部插件，提供对当前仅对高级用户可用的特定功能的访问......"
},{
	"code":"PJSONBROWSER",
	"name":"JSON Browser",
	"en_text":"The IntelliJ JSON Explorer Plugin lets you browse, compare, and edit JSON data in multiple views like JSON view, table view, and tree view. Compare two JSONs, track...",
	"ch_text":"IntelliJ JSON Explorer 插件允许您在多个视图（如 JSON 视图、表视图和树视图）中浏览、比较和编辑 JSON 数据。比较两个 JSON，跟踪..."
},{
	"code":"PEXTRAIDETWEAKS",
	"name":"Extra IDE Tweaks",
	"en_text":"Some utilities for IDE maintenance and tweaking, plus workarounds for a few IDE issues. See Tools &amp;gt; Extra IDE Tweaks. Features: The Open Editors tool window shows...",
	"ch_text":"一些用于 IDE 维护和调整的实用程序，以及一些 IDE 问题的解决方法。请参阅工具 &amp;gt; 额外的 IDE 调整。功能： Open Editors （打开编辑器） 工具窗口显示..."
},{
	"code":"PGERRYCOFFEE",
	"name":"Gerry Coffee",
	"en_text":"This plugin is Coffee theme from Gerry Themes Pro, allowing you to purchase specific theme with lower price. Gerry Coffee(Pro): A dark brown tone theme, inspired by...",
	"ch_text":"这个插件是 Gerry Themes Pro 的咖啡主题，允许您以较低的价格购买特定的主题。Gerry Coffee（Pro）：深棕色调主题，灵感来自......"
},{
	"code":"PBRWJV",
	"name":"AutoCode for Java",
	"en_text":"AutoCode for Java is a plugin for automating programming and for exploring Java codebases. The AutoCode tool window provides a GUI for programming Java, it can also be...",
	"ch_text":"AutoCode for Java 是一个用于自动化编程和探索 Java 代码库的插件。AutoCode 工具窗口提供了一个用于 Java 编程的 GUI，它也可以是......"
},{
	"code":"PSEQDIAORG",
	"name":"SequenceDiagram.org",
	"en_text":"Official offline version of the SequenceDiagram.org UML sequence diagram tool. Create sequence diagrams through File -&amp;gt; New or Right click in project -&amp;gt; New See...",
	"ch_text":"SequenceDiagram.org UML 序列图工具的官方离线版本。通过 File -&amp;gt; New 或在项目中右键单击 -&amp;gt; New See ... 创建序列图"
},{
	"code":"PCDAPIRUNNER",
	"name":"API Runner",
	"en_text":"Keywords: dubbo, http, ApiManager, test, grpc A light tool that enables you to test your HTTP or Dubbo API or GRPC API quickly and easily. For developers to manually...",
	"ch_text":"关键词：dubbo、http、ApiManager、test、gRPC 一个轻量级的工具，让你可以快速、轻松地测试你的 HTTP 或 Dubbo API 或 GRPC API。对于开发人员手动..."
},{
	"code":"PJMETERRUNNER",
	"name":"JMeter Runner",
	"en_text":"Provides support to run jmeter test plans. Features: Run test plan on JMeter.",
	"ch_text":"支持运行 jmeter 测试计划。功能特性：在 JMeter 上运行测试计划。"
},{
	"code":"PLATTEPRO",
	"name":"Latte Pro",
	"en_text":"Best and fastest Latte language plugin. Provides support for Latte – a template engine for PHP. It&#39;s a must have plugin for Nette developers. !! For older Latte...",
	"ch_text":"最好和最快的拿铁语言插件。提供对 Latte 的支持 – PHP 的模板引擎。这是 Nette 开发人员必备的插件。!!对于老拿铁..."
},{
	"code":"PRUBYCODESUGG",
	"name":"Auto Ruby Code Suggestions",
	"en_text":"Ruby Code Suggestions is a tool that you can use for generating code, just write what you want, like (Add two numbers) and you will get a function that does what you...",
	"ch_text":"Ruby Code Suggestions 是一个可以用来生成代码的工具，只需编写你想要的，比如 （Add two numbers），你就会得到一个函数来做你..."
},{
	"code":"PZEROCODE",
	"name":"Zerocode Scenario Helper",
	"en_text":"Adds support for writing Zerocode scenarios. The plugin has the following features: keyword completion suggestions scenario files are validated against json/yaml...",
	"ch_text":"添加了对编写 Zerocode 方案的支持。该插件具有以下特点：关键字补全建议场景文件根据 json/yaml 进行验证..."
},{
	"code":"PLEDGER",
	"name":"LedgerPlugin",
	"en_text":"This plugin adds Ledger CLI support to JetBrains IDEs: syntax highlighting, autocomplete,unpaid invoices detection and marking,simple formatting.",
	"ch_text":"此插件为 JetBrains IDE 添加了 Ledger CLI 支持：语法高亮、自动完成、未付发票检测和标记、简单格式化。"
},{
	"code":"PINTELLIPHP",
	"name":"IntelliPHP - AI Autocomplete for PHP",
	"en_text":"IntelliPHP is a local AI-powered extension for IntelliJ IDEs that enhances productivity and code development experience for PHP. Full-Line code completions IntelliPHP...",
	"ch_text":"IntelliPHP 是 IntelliJ IDE 的本地 AI 驱动的扩展，可提高 PHP 的生产力和代码开发体验。全行代码补全 IntelliPHP..."
},{
	"code":"PCHATGPTCODING",
	"name":"ChatGPT Coding",
	"en_text":"Welcome to ChatGPT Coding! Here, you can utilize the ApiKey registered on the OpenAI official website to write code and receive suggestions and examples from ChatGPT...",
	"ch_text":"欢迎来到 ChatGPT 编码！在这里，你可以利用在 OpenAI 官网注册的 ApiKey 来编写代码，并从 ChatGPT 接收建议和示例......"
},{
	"code":"PLANGUAGEPACKES",
	"name":"Spanish Language Pack / Paquete De Idioma Español",
	"en_text":"The Spanish Language Pack for IJ IDEs family. El Paquete de Idioma Español para la familia de IDEs IJ. Para activar, vaya a Settings | Appearance &amp;amp; Behavior...",
	"ch_text":"用于 IJ IDE 的西班牙语语言包系列。El Paquete de Idioma Español para la familia de IDEs IJ.Para activar， vaya a Settings |外观和行为..."
},{
	"code":"PCODEKITS",
	"name":"CodeKits",
	"en_text":"ChatGPT Integration with Codekits - Enhancing Coding Productivity ChatGPT Integration with Codekits can significantly enhance your coding productivity, enabling you to...",
	"ch_text":"ChatGPT 与 Codekits 集成 - 提高编码效率 ChatGPT 与 Codekits 的集成可以显着提高您的编码效率，使您能够......"
},{
	"code":"PNEXTSKETCH",
	"name":"NextSketch",
	"en_text":"NextSketch gives developers a simple diagramming tool useful when designing product architecture. It&#39;s completely integrated into the IDE, lets you keep diagrams...",
	"ch_text":"NextSketch 为开发人员提供了一个简单的图表工具，在设计产品架构时非常有用。它完全集成到 IDE 中，让您保留图表......"
},{
	"code":"PONEGAICOPILOT",
	"name":"Onegai Copilot",
	"en_text":"Is an AI-powered coding assistant that helps you write code faster and with fewer errors. It uses the OpenAI API to provide code completions, generate code from...",
	"ch_text":"是一款 AI 驱动的编码助手，可帮助您更快地编写代码并减少错误。它使用 OpenAI API 提供代码补全，从..."
},{
	"code":"PSENTRY",
	"name":"Sentry",
	"en_text":"The Sentry plugin allows you to browse issues, events, and stacktraces right in your IDE. Free Features: Browse issues and eventsView stacktraces and navigate to the...",
	"ch_text":"Sentry 插件允许您直接在 IDE 中浏览问题、事件和堆栈跟踪。免费功能：浏览问题和事件查看堆栈跟踪并导航到..."
},{
	"code":"POPENAPICRUDWIZ",
	"name":"OpenAPI CRUD Wizard",
	"en_text":"OpenAPI CRUD Wizards creates a new OpenAPI document including CRUD operations. The wizard takes input from: Selected text in the editor within any file.Selected Yaml...",
	"ch_text":"OpenAPI CRUD 向导会创建一个包含 CRUD作的新 OpenAPI 文档。向导从以下位置获取输入：编辑器中任何文件中的选定文本。选定的 Yaml..."
},{
	"code":"PVERILOGLANGUAG",
	"name":"Verilog Language Support",
	"en_text":"Adds support for Verilog (IEEE 1364-2005) language. The following features are available with IntelliJ IDEA Community Edition: Syntax highlighting Find definition and...",
	"ch_text":"添加对 Verilog （IEEE 1364-2005） 语言的支持。IntelliJ IDEA 社区版提供以下功能： 语法高亮显示 查找定义和..."
},{
	"code":"PLANGUAGEPACKRU",
	"name":"Russian Language Pack / Локализация IDE На Русский Язык",
	"en_text":"The Russian Language Pack for IJ IDEs family. Плагин Локализации IntelliJ IDE на русский язык. Для активации перейдите в Settings | Appearance &amp;amp; Behavior | System...",
	"ch_text":"IJ IDE 系列的俄语语言包。Плагин Локализации IntelliJ IDE на русский язык.Для активации перейдите в Settings |外观与行为 |系统。。。"
},{
	"code":"PMRINTEGEE",
	"name":"Merge Request Integration EE - Code Review for GitLab",
	"en_text":"Merge Request Integration EE is an open-source plugin for JetBrains IDEs which helps you Do code review right in your IDE. Address review comments from your...",
	"ch_text":"Merge Request Integration EE 是 JetBrains IDE 的开源插件，可帮助您直接在 IDE 中进行代码审查。处理来自您的评论评论..."
},{
	"code":"PHPBUILDER",
	"name":"PHP Data Object Generator",
	"en_text":"PHP Data Object Generator Description Code generator plugin for PHP Data Objects (Value Object, DTO/Data Transfer Object, etc...) and Builder pattern objects for...",
	"ch_text":"PHP 数据对象生成器 描述 用于 PHP 数据对象（值对象、DTO/数据传输对象等）和构建器模式对象的代码生成器插件..."
},{
	"code":"PWXUQRYTOXCRSEO",
	"name":"RustTool",
	"en_text":"English: Simple tools for the rust programming language Supports: Api Navigation for Salvo Web Framework. (very useful when there are many APIs) Support...",
	"ch_text":"中文（简体）：Rust 编程语言的简单工具 支持：Salvo Web 框架的 API 导航。（当 API 很多时非常有用）支持。。。"
},{
	"code":"PGITHUBCI",
	"name":"Github CI Dashboard",
	"en_text":"Github CI Dashboard Manage your GitHub CI jobs from your JetBrains IDE. Features 🔐 Login to GitHub through web or personal token.📋 List public and user projects in a...",
	"ch_text":"Github CI 控制面板 从 JetBrains IDE 管理您的 GitHub CI 作业。功能 🔐 通过 Web 或个人令牌登录 GitHub。📋在..."
},{
	"code":"PSMARTTOMCATPRO",
	"name":"Smart Tomcat Pro",
	"en_text":"Smart Tomcat Pro: Smart, Powerful, Redefined SmartTomcat Pro is a powerful plugin for IntelliJ IDEA, available for both Community and Ultimate editions, designed to...",
	"ch_text":"Smart Tomcat Pro：智能、强大、重新定义的 SmartTomcat Pro 是 IntelliJ IDEA 的强大插件，可用于社区版和旗舰版，旨在......"
},{
	"code":"PDRYPUSH",
	"name":"DryPush: AWS | GCP | Alibaba Deploy &amp; Upload",
	"en_text":"Simplify cloud deployments to AWS, Google Cloud Platform, Alibaba Cloud and other cloud services. 1-2-3-Ready! AWS Services S3 EC2 Elastic Beanstalk Lambda Lightsail...",
	"ch_text":"简化到 AWS、Google Cloud Platform、阿里云和其他云服务的云部署。1-2-3-准备好了！AWS 服务 S3 EC2 Elastic Beanstalk Lambda Lightsail"
},{
	"code":"PVOQAL",
	"name":"Voqal Coder",
	"en_text":"Voqal is a programming assistant built for software developers looking to enhance their productivity with natural speech programming. Using Voqal, you can navigate...",
	"ch_text":"Voqal 是一款编程助手，专为希望通过自然语音编程提高生产力的软件开发人员而构建。使用 Voqal，您可以导航..."
},{
	"code":"PWAUFKYVHQCRXEO",
	"name":"IoGame",
	"en_text":"English: Support for IoGame game framework, detailed documentation connection. Document 中文: 对IoGame游戏框架进行的支持，详细文档连接. QQ群: 289132257 (有折扣). 注: 有什么问题都可以进群询问. 文档.",
	"ch_text":"英文：支持 IoGame 游戏框架，详细文档连接。Document 中文： 对IoGame游戏框架进行的支持，详细文档连接.QQ群： 289132257 （有折扣）.注: 有什么问题都可以进群询问.文档."
},{
	"code":"PCIRCLECI",
	"name":"CircleCI Dashboard",
	"en_text":"CircleCI CI Dashboard Manage your CircleCI workflows from your JetBrains IDE. Features 🔐️ Quick connect to your CircleCI account with a personal token.🖥 Keep track...",
	"ch_text":"CircleCI 仪表板 从 JetBrains IDE 管理您的 CircleCI 工作流。功能 🔐️ 使用个人令牌快速连接到您的 CircleCI 帐户。🖥保持跟踪..."
},{
	"code":"PQUERYFLAG",
	"name":"QueryFlag",
	"en_text":"Define and execute template based queries on selected text. Ever wanted to replace easily a single query parameter from within your editor? Now you can, with QueryFlag...",
	"ch_text":"定义和执行基于所选文本的模板查询。是否曾想过从编辑器中轻松替换单个查询参数？现在，您可以使用 QueryFlag..."
},{
	"code":"POXYJSONCONVERT",
	"name":"JSON-YAML-XML Converter",
	"en_text":"This is a plugin for converting JSON, YAML and XML files. To perform a conversion, follow these steps: Once installed, go to Tools, or right-click on a JSON, YAML, or...",
	"ch_text":"这是一个用于转换 JSON、YAML 和 XML 文件的插件。要执行转换，请执行以下步骤：安装后，转到工具，或右键单击 JSON、YAML 或..."
},{
	"code":"PBUILDMON",
	"name":"Build Monitor",
	"en_text":"Build Monitor Description Monitor Github Action Workflows and Buildkite Builds from within your IDE. Setup profiles which automatically refresh the status of your...",
	"ch_text":"构建监视器 描述 从 IDE 中监控 Github作工作流和 Buildkite 构建。设置配置文件，可自动刷新您的配置文件的状态。"
},{
	"code":"PMYSQLPROXY",
	"name":"MySQL Proxy",
	"en_text":"An IntelliJ IDEA plugin that records code CRUD operations and assists you in identifying SQL queries with potential issues while providing optimization suggestions...",
	"ch_text":"一个 IntelliJ IDEA 插件，用于记录代码 CRUD作，并帮助您识别存在潜在问题的 SQL 查询，同时提供优化建议..."
},{
	"code":"PAAAA",
	"name":"Combine and Copy Files to Clipboard",
	"en_text":"Combine and Copy the content of multiple files to the clipboard, split by path and relative file names. Ideal for providing better context to LLMs such as OpenAI&#39;s...",
	"ch_text":"将多个文件的内容合并并复制到剪贴板，按路径和相对文件名进行拆分。非常适合为 LLM 提供更好的上下文，例如 OpenAI 的..."
},{
	"code":"PFUZYFIPC",
	"name":"Find In Files (Favorites)",
	"en_text":"Favorite searches of Find in Files action. Productivity plugin | Save your frequently used search configuration for repeated use. Favorites are saved per project...",
	"ch_text":"收藏的 Find in Files作的搜索。生产力插件 |保存您经常使用的搜索配置以供重复使用。收藏夹按项目保存..."
},{
	"code":"PMINBATIS",
	"name":"MinBatis",
	"en_text":"The MinBatis plugin provides MyBatis framework support in IntelliJ IDEA. Getting Started in IntelliJ IDEA Change Log Issue tracker Discussion.",
	"ch_text":"MinBatis 插件在 IntelliJ IDEA 中提供 MyBatis 框架支持。IntelliJ IDEA 更改日志问题跟踪器讨论入门。"
},{
	"code":"PCAPREDIS",
	"name":"Cap-Redis",
	"en_text":"An advanced GUI client for Redis, Support Standalone/Sentinel/Cluster &amp;amp; SSH, Support redis-cli &amp;amp; command wrap, almost all commands are supported, You&#39;ll like...",
	"ch_text":"一个高级的Redis图形用户界面客户端，支持独立/哨兵/集群和SSH，支持redis-cli和命令包装，几乎所有的命令都支持，你会喜欢..."
},{
	"code":"PJQEXPRESS",
	"name":"jqExpress",
	"en_text":"JqExpress is a powerful plugin for IntelliJ IDEA that brings seamless JSON querying and transformation capabilities to your development workflow. Whether you&#39;re...",
	"ch_text":"JqExpress 是 IntelliJ IDEA 的强大插件，可为您的开发工作流程提供无缝的 JSON 查询和转换功能。无论您是..."
},{
	"code":"PRANCHER",
	"name":"Rancher",
	"en_text":"Working with pods using Rancher cli View logs in POD Execute shell commands in POD Upload local disk files or folders to POD Download file or folder from POD to local...",
	"ch_text":"使用 Rancher cli 处理 Pod 在 POD 中查看日志 在 POD 中执行 shell 命令 将本地磁盘文件或文件夹上传到 POD 将文件或文件夹从 POD 下载到本地..."
},{
	"code":"POXYJSONSCHGEN",
	"name":"JSON Schema Generator",
	"en_text":"This is a plugin for generating a sample JSON Schema from a JSON file. To generate a sample JSON Schema file, follow these steps: Once installed, go to Tools -&amp;gt...",
	"ch_text":"这是一个用于从 JSON 文件生成示例 JSON 架构的插件。要生成示例 JSON 架构文件，请执行以下步骤：安装后，转到工具 -&gt;..."
},{
	"code":"PWIREMOCHA",
	"name":"WireMocha",
	"en_text":"WireMocha is an IntelliJ-based plugin that provides framework integration for the WireMock library. It offers various tools to generate and validate WireMock related...",
	"ch_text":"WireMocha 是一个基于 IntelliJ 的插件，为 WireMock 库提供框架集成。它提供了各种工具来生成和验证与 WireMock 相关的..."
},{
	"code":"PJMETERPLUGINSM",
	"name":"JMeter Plugins Manager",
	"en_text":"Provides support to install and suggest jmeter plugins for test plans. Features: Install JMeter plugins Suggest JMeter plugins.",
	"ch_text":"支持为测试计划安装和建议 jmeter 插件。功能： 安装 JMeter 插件 建议 JMeter 插件。"
},{
	"code":"PVCS",
	"name":"commit-template",
	"en_text":"Create a commit message using a user-defined template. Easily and quickly input emoji code. FeaturesSupport custom template commit messageSupport custom form commit...",
	"ch_text":"使用用户定义的模板创建提交消息。轻松快速地输入表情符号代码。功能支持自定义模板提交消息支持自定义表单提交..."
},{
	"code":"PFEIGNHELPER",
	"name":"Feign-Helper",
	"en_text":"Feign-Helper is a tool plugin that supports the Spring framework. It helps developers quickly find urls in source code and quickly copy paths in Spring Web Controller...",
	"ch_text":"Feign-Helper 是一个支持 Spring 框架的工具插件。它可以帮助开发人员在源代码中快速找到 url，并在 Spring Web Controller 中快速复制路径......"
},{
	"code":"PMAVENSEARCHER",
	"name":"MavenSearcher",
	"en_text":"MavenSearcher MavenSearcher is a powerful IntelliJ plugin designed to enhance your Maven experience. Seamlessly integrated with Maven Central, it allows you to search...",
	"ch_text":"MavenSearcher MavenSearcher 是一个功能强大的 IntelliJ 插件，旨在增强您的 Maven 体验。它与 Maven Central 无缝集成，允许您搜索..."
},{
	"code":"PPOJOTOJSONSCH",
	"name":"POJO to JSON Schema",
	"en_text":"Generates JSON Schemas from Java classes. Generated json schemas locates under .generated-json-schemas folder. How to use Right click on Java class: Click POJO to JSON...",
	"ch_text":"从 Java 类生成 JSON 架构。生成的 json 架构位于 .generated-json-schemas 文件夹下。如何使用 Right Click on Java 类：单击 POJO 到 JSON..."
},{
	"code":"PLANGUAGEPACKDE",
	"name":"Deutsch (German) Language Pack / Deutsches Sprachpaket",
	"en_text":"The Deutsch Language Pack for IJ IDEs family. Das Deutsche Sprachpaket für die IJ IDE-Familie. Um die Aktivierung durchzuführen, gehen Sie zu Settings | Appearance...",
	"ch_text":"Deutsch Language Pack for IJ IDE 系列。Das Deutsche Sprachpaket für die IJ IDE-Familie.Um die Aktivierung durchzuführen， gehen Sie zu Settings |外观。。。"
},{
	"code":"PBITRISECI",
	"name":"Bitrise Dashboard",
	"en_text":"Bitrise CI Dashboard Manage your Bitrise CI jobs from your JetBrains IDE. Features 🔐 Login to Bitrise through web or personal token.📋 List your projects.🖥 Keep...",
	"ch_text":"Bitrise CI 仪表板 从 JetBrains IDE 管理您的 Bitrise CI 作业。特点 🔐 通过网络或个人令牌登录Bitrise。📋列出您的项目。🖥保持..."
},{
	"code":"PTRAVISCI",
	"name":"Travis CI Dashboard",
	"en_text":"Travis CI Dashboard Manage your Travis CI pipelines from your JetBrains IDE. Features 🔐 Login to Travis.com or Travis enterprise instance.📋 List your projects...",
	"ch_text":"Travis CI 仪表板 从 JetBrains IDE 管理您的 Travis CI 管道。功能 🔐 登录到 Travis.com 或 Travis 企业实例。📋列出您的项目..."
},{
	"code":"PLANGUAGEPACKFR",
	"name":"French Language Pack / Pack De Langue Français",
	"en_text":"The French Language Pack for IntelliJ IDE family.Le Pack de langue français pour la famille d&#39;IDE IntelliJ. Pour activer, allez dans Settings | Appearance &amp;amp...",
	"ch_text":"IntelliJ IDE 系列的法语语言包。Le Pack de langue français pour la famille d'IDE IntelliJ.Pour activer， allez dans 设置 |外观 &amp; ..."
},{
	"code":"PSEQUENCEOUTLIN",
	"name":"SequenceOutline",
	"en_text":"Sequence PlantUML and Json Tools and Mock and Record for Mock and Restful plugin Traverse the code according to the configuration to generate the call tree Display the...",
	"ch_text":"对 PlantUML 和 Json 工具进行排序，并为 Mock 和 Restful 插件进行 Mock 和 Record 根据配置遍历代码以生成调用树 显示..."
},{
	"code":"PCAPELASTIC",
	"name":"Cap-Elasticsearch",
	"en_text":"This Elasticsearch client allows accessing to Elasticsearch cluster, browse and edit your data, execute REST API requests, execute SQL query. Documentation | Github...",
	"ch_text":"此 Elasticsearch 客户端允许访问 Elasticsearch 集群、浏览和编辑数据、执行 REST API 请求、执行 SQL 查询。文档 |Github..."
},{
	"code":"PSOURCESYNCPRO",
	"name":"Source Synchronizer Pro",
	"en_text":"A fast, one-way file synchronization tool for your projects. Sourcesync Pro&#39;s synchronization, forwarding and comparison capabilities for local vs remote files provide...",
	"ch_text":"适用于您的项目的快速单向文件同步工具。Sourcesync Pro 的本地文件与远程文件的同步、转发和比较功能提供..."
},{
	"code":"PASTOCK",
	"name":"AStock",
	"en_text":"AStock is an IDE plugin that provides China stock analysis, including MACD, SKDJ, KDJ, RSI, and TD9. Also Support today/last-hot, bull-rank, and macd-crossed-up...",
	"ch_text":"AStock 是一个提供中国股票分析的 IDE 插件，包括 MACD、SKDJ、KDJ、RSI 和 TD9。还支持 today/last-hot、bull-rank 和 macd-crossed-up..."
},{
	"code":"PJSCODESUGG",
	"name":"Auto Javascript Code Suggestions",
	"en_text":"javascript Code Suggestions is a tool that you can use for generating code, just write what you want, like (Add two numbers) and you will get a function that does what...",
	"ch_text":"javascript Code Suggestions 是一个可以用来生成代码的工具，只需编写你想要的，比如 （Add two numbers），你就会得到一个函数，它可以做什么......"
},{
	"code":"PELSA",
	"name":"ElasticSearch-Admin",
	"en_text":"A simple tool allows you to administrate ElasticSearch. Following features are available: 1.normal &amp;amp; ssh-tunnel elasticsearch access 2.elasticsearch...",
	"ch_text":"一个简单的工具允许您管理 ElasticSearch。以下功能可用：1.正常和ssh-tunnel elasticsearch访问 2.elasticsearch..."
},{
	"code":"PDJANGOTPLPEP",
	"name":"Typed Django Template",
	"en_text":"PEP 484(Type Hint) for Django Template. Django template variable type annotate, code auto-complete, find usage, attribute rename (code refactor), invalid...",
	"ch_text":"PEP 484（type hint） 用于 Django 模板。Django 模板变量类型注释、代码自动完成、查找用法、属性重命名（代码重构）、无效......"
},{
	"code":"PWXUFQYRHZCRSEO",
	"name":"Gorm",
	"en_text":"English: A go language gorm entity generator, supports tag generation selection, json, form, supports camel case generation selection. Support API generation and...",
	"ch_text":"英文：一个 go 语言 gorm 实体生成器，支持标签生成选择、json、form，支持驼峰大小写生成选择。支持 API 生成和..."
},{
	"code":"PNETLIFY",
	"name":"Netlify Dashboard",
	"en_text":"Netlify Dashboard Plugin Manage your Netlify sites and deployment builds from your IDE. Features 🖥 List sites, preview, useful links and response time.🛠 View builds...",
	"ch_text":"Netlify 仪表板插件 从 IDE 管理您的 Netlify 站点和部署版本。功能 🖥 列出站点、预览、有用的链接和响应时间。🛠查看版本..."
},{
	"code":"PSQLFLUFFLINTER",
	"name":"Sqlfluff Linter (Ultimate Edition)",
	"en_text":"Provides support for the SQLfluff linter. Note: Please make sure to install sqlfluff; pip install sqlfluff Features: SQLfluff linter integration Quick fixes for simple...",
	"ch_text":"提供对 SQLfluff linter 的支持。注意：请确保安装 sqlfluff;pip install sqlfluff 功能：SQLfluff linter 集成 快速修复简单的..."
},{
	"code":"PSPARQL",
	"name":"SPARQL",
	"en_text":"Plugin to develop and test SPARQL queries and discover datasets in the Linked Open Data. Documentation.",
	"ch_text":"用于开发和测试 SPARQL 查询并在 Linked Open Data 中发现数据集的插件。文档。"
},{
	"code":"PCONNECTUI",
	"name":"Connect Api",
	"en_text":"Connect API ToolWindow for Kafka Connect Description A GUI/ToolWindow for interacting with Kafka Connect over its REST API. Allows for inspecting, monitoring, and...",
	"ch_text":"Connect API 用于 Kafka Connect 的 ToolWindow 描述 用于通过其 REST API 与 Kafka Connect 交互的 GUI/ToolWindow。允许检查、监控和..."
},{
	"code":"POWASPIDEVULSCA",
	"name":"OWASP IDE-VulScanner",
	"en_text":"OWASP IDE-VulScanner is an open source IDE plugin tool to analyze an application’s components. It is built on top of OWASP Dependency Check, which scans your...",
	"ch_text":"OWASP IDE-VulScanner 是一个开源的 IDE 插件工具，用于分析应用程序的组件。它建立在 OWASP Dependency Check 之上，OWASP Dependency Check 会扫描您的..."
},{
	"code":"PAPH",
	"name":"Android Package Helper",
	"en_text":"Find Android apps package, common intents to interact with popular apps. Features are available from the &quot;Tools&quot; tab, then &quot;Android Package Helper&quot; Two options...",
	"ch_text":"查找 Android 应用程序包，与热门应用程序交互的常见意图。功能可从“工具”选项卡获得，然后从“Android Package Helper”两个选项..."
},{
	"code":"POXYJSONDIAGRAM",
	"name":"JSON Schema Visualizer/Editor",
	"en_text":"This plugin contributes a powerful, expressive visual schema diagram editor (Design mode) for editing JSON Schemas in your preferred IDE. The structure of the JSON...",
	"ch_text":"此插件提供了一个功能强大、富有表现力的可视化架构图编辑器（设计模式），用于在首选 IDE 中编辑 JSON 架构。JSON 的结构..."
},{
	"code":"PSRCODEGEN",
	"name":"Spring Rest Code Generator",
	"en_text":"Plugin to generate a Spring Rest API in an easier way. This plugin adds automatic code generation capabilities to facilitate the development of RESTful APIs using the...",
	"ch_text":"Plugin 以更简单的方式生成 Spring Rest API。此插件添加了自动代码生成功能，以促进使用..."
},{
	"code":"PCUEFY",
	"name":"Cuefy",
	"en_text":"Cuefy plugin provides support for CUE language. Features: Parse CUE files and check the grammarHighlight CUE filesAutoPreview functionality (you can see the output...",
	"ch_text":"Cuefy 插件提供对 CUE 语言的支持。功能： 解析 CUE 文件并检查语法突出显示 CUE 文件自动预览功能（您可以看到输出..."
},{
	"code":"PSENTRYINTEG",
	"name":"Sentry Integration",
	"en_text":"Sentry Integration is an open-source which helps you check sentry&#39;s issues, navigate exception&#39;s stacktrace right in your IDE. What you can do: View sentry&#39;s issues...",
	"ch_text":"Sentry 集成是一个开源软件，可帮助您直接在 IDE 中检查 Sentry 的问题、导航异常的堆栈跟踪。您可以做什么： 查看 sentry 的问题..."
},{
	"code":"PQMLEDITOR",
	"name":"QmlEditor",
	"en_text":"QML Editor helps to work with QML (Qt Modeling Language). IMPORTANT: Please uninstall or deactivate QML Support plugin before installing QML Editor. Plugins conflict...",
	"ch_text":"QML 编辑器有助于使用 QML（Qt 建模语言）。重要提示：在安装 QML 编辑器之前，请卸载或停用 QML Support 插件。插件冲突..."
},{
	"code":"PLOCALESPHERE",
	"name":"Locale Sphere",
	"en_text":"Locale Sphere. The plugin helps to manage localization strings. Current supported frameworks: Android PHP: Laravel, Symfony.",
	"ch_text":"区域设置球体。该插件有助于管理本地化字符串。当前支持的框架： Android PHP： Laravel， Symfony."
},{
	"code":"PSTRKER",
	"name":"Stryker",
	"en_text":"Integrates StrykerJS under the common IntelliJ test framework. This plugin does not support Stryker for other languages Features Introduce Stryker run configuration...",
	"ch_text":"将 StrykerJS 集成到通用的 IntelliJ 测试框架下。此插件不支持其他语言的 Stryker 功能介绍 Stryker 运行配置..."
},{
	"code":"PMYBATISCODE",
	"name":"MyBatis Plus Tools",
	"en_text":"MyBatis Plus Tools plugin for java mybatis framework, provide auto code generation bilibili||xigua Features: Usage: Right-click on the MybatisCode menu in IntelliJ’s...",
	"ch_text":"MyBatis Plus Tools 插件 for java mybatis 框架，提供自动代码生成 bilibili||xigua 功能： 用法：右键单击 IntelliJ 的 MybatisCode 菜单..."
},{
	"code":"PNEXTSKETCHTWO",
	"name":"NextSketch2",
	"en_text":"NextSketch 2 is a plugin for IntelliJ-Platform IDEs that lets teams design architecture diagrams for your project. It&#39;s integrated right into the IDE, and diagrams...",
	"ch_text":"NextSketch 2 是 IntelliJ-Platform IDE 的插件，可让团队为您的项目设计架构图。它直接集成到 IDE 和图表中......"
},{
	"code":"POFFICEFLOOR",
	"name":"OfficeFloor",
	"en_text":"Enables OfficeFloor development with IntelliJ.",
	"ch_text":"使用 IntelliJ 支持 OfficeFloor 开发。"
},{
	"code":"PKAFKAIDE",
	"name":"Kafkaide",
	"en_text":"Kafka CLI to GUI,Help developers quickly operate Kafka cluster. Features: multiple clusters support brokers management create template classes for kafka produce and...",
	"ch_text":"Kafka CLI 转 GUI，帮助开发者快速作 Kafka 集群。功能：多个集群支持 broker management 为 Kafka 创建模板类 produce 和 ..."
},{
	"code":"PGPTASSISTANT",
	"name":"GPT Assistant",
	"en_text":"Supercharge Your JetBrains Rider with GPT Assistant Transform your development workflow with the GPT Assistant Plugin for JetBrains Rider. Leveraging the power of...",
	"ch_text":"使用 GPT Assistant 为您的 JetBrains Rider 增强 使用适用于 JetBrains Rider 的 GPT Assistant 插件转变您的开发工作流程。利用 ..."
},{
	"code":"PMICRONAUTLAUNC",
	"name":"Micronaut Launch",
	"en_text":"Provides Micronaut launch New Project wizard. Micronaut Launch is a Project wizard that allows you to create Micronaut projects through an interface instead of using...",
	"ch_text":"提供 Micronaut 启动新建项目向导。Micronaut Launch 是一个项目向导，允许您通过界面创建 Micronaut 项目，而不是使用..."
},{
	"code":"PLANGUAGEPACKPT",
	"name":"Portuguese Language Pack / Pacote De Idioma Português",
	"en_text":"The Portuguese Language Pack for IJ IDEs family. Pacote de Idioma Português para a família de IDEs IJ. Para ativar, vá em Configurações | Aparência e Comportamento...",
	"ch_text":"用于 IJ IDE 的葡萄牙语语言包系列。Pacote de Idioma Português para a família de IDEs IJ.Para ativar， vá em Configurações |Aparência e Comportamento..."
},{
	"code":"PFASTSHELL",
	"name":"FastShell",
	"en_text":"Fast Shell supports the management of custom scripts, which can quickly execute shell commands. The supported commands depend on the shell environment used by the...",
	"ch_text":"Fast Shell 支持自定义脚本的管理，可以快速执行 shell 命令。支持的命令取决于 shell 环境..."
},{
	"code":"PHTMXPRO",
	"name":"HTMX Pro",
	"en_text":"HTMX Pro plugin provides comprehensive support for the htmx library in JetBrains IDEs. Features Provides advanced coding assistance, including syntax highlighting...",
	"ch_text":"HTMX Pro 插件为 JetBrains IDE 中的 htmx 库提供全面支持。功能 提供高级编码帮助，包括语法高亮显示..."
},{
	"code":"PCOLORBRACKETS",
	"name":"Color Brackets",
	"en_text":"Colorize brackets for IntelliJ-based IDEs. Supports multiple languages, Java, C, C++, C#, Python, JavaScript, Typescript, Go, SQL, Kotlin ... Note: Color brackets...",
	"ch_text":"为基于 IntelliJ 的 IDE 着色括号。支持多种语言，Java、C、C++、C#、Python、JavaScript、Typescript、Go、SQL、Kotlin ...注意：彩色括号..."
},{
	"code":"PPHPHOUDINI",
	"name":"PHP Houdini",
	"en_text":"Enable configurable completion of magic properties and methods using a configuration file written in PHP. Create a file named .houdini.php in the root of your project...",
	"ch_text":"使用用 PHP 编写的配置文件启用魔术属性和方法的可配置完成。在项目的根目录中创建一个名为 .houdini.php 的文件..."
},{
	"code":"PNFLUTTER",
	"name":"NFlutter",
	"en_text":"NFlutter is a DSL (Mini Language) designed for Flutter Widgets development. It acts as a powerful code generator, transforming concise NFlutter code into standard Dart...",
	"ch_text":"NFlutter 是一种专为 Flutter Widgets 开发而设计的 DSL（迷你语言）。它充当一个强大的代码生成器，将简洁的 NFlutter 代码转换为标准的 Dart......"
},{
	"code":"PJTRACKER",
	"name":"JTracker: MyBatis Log &amp; JPA Log",
	"en_text":"JTracker is a java code tracking tool that allows you to quickly locate where MyBatis and JPA SQL is executing and the call trace. Features Support for complete...",
	"ch_text":"JTracker 是一个 java 代码跟踪工具，它允许你快速找到 MyBatis 和 JPA SQL 的执行位置以及调用跟踪。功能 支持完整的..."
},{
	"code":"PSCIPIOMGNL",
	"name":"Magnolia CMS Integration",
	"en_text":"Magnolia CMS Integration: Autocomplete, Documentation, Highlighting and other tools for the efficient Magnolia developer! Features: Custom Editor for Freemarker files...",
	"ch_text":"Magnolia CMS 集成：自动完成、文档、突出显示和其他工具，适用于高效的 Magnolia 开发人员！特点：Freemarker 文件的自定义编辑器..."
},{
	"code":"PWGCODECREATOR",
	"name":"codeCreator",
	"en_text":"codeCreator is a general purpose code generator plugin for JetBrains IntelliJ IDEA and Android Studio IDEs. It allows for the creation of a code generation task that...",
	"ch_text":"codeCreator 是适用于 JetBrains IntelliJ IDEA 和 Android Studio IDE 的通用代码生成器插件。它允许创建一个代码生成任务..."
},{
	"code":"PSQLDEBUGGER",
	"name":"SQLDebugger",
	"en_text":"This tool help you to debug your SELECT/WITH SQL with variables, such as select * from customers where customer_id = :customer_id or select * from customers where...",
	"ch_text":"此工具可帮助您调试带有变量的 SELECT/WITH SQL，例如 select * from customers where customer_id = ：customer_id 或 select * from customers where..."
},{
	"code":"PDLXRJAS",
	"name":"Resilience4j Annotation Support",
	"en_text":"Add support for Resilience4j annotations. 为 Resilience4j annotation 添加额外支持。 Free features: Provides auto-completion, method navigation for the fallbackMethod attribute...",
	"ch_text":"添加对 Resilience4j 注释的支持。为 Resilience4j annotation 添加额外支持。免费功能：为 fallbackMethod 属性提供自动完成、方法导航..."
},{
	"code":"PSCHEMAREGVIEW",
	"name":"Schema Registry Viewer",
	"en_text":"Browse schemas persisted in external Schema Registry: Review all versions of given schema Graphically visualize complex schemas defined in Apache Avro Compare...",
	"ch_text":"浏览保存在外部架构注册表中的架构：查看给定架构的所有版本 以图形方式可视化 Apache Avro Compare..."
},{
	"code":"PSOTERISECURITY",
	"name":"Soteri Secret Scanner",
	"en_text":"Detect Secrets While DevelopingA real-time IntelliJ vulnerability scanner that detects secrets in your code and queries. Mitigate data leaks early in the development...",
	"ch_text":"在开发时检测密钥实时 IntelliJ 漏洞扫描程序，用于检测代码和查询中的密钥。在开发早期减少数据泄露..."
},{
	"code":"PSPEECHTOTEXT",
	"name":"Speech-To-Text (AWS Transcribe)",
	"en_text":"Speech-To-Text (Aws Transcribe) Capture your voice effortlessly in IntelliJ! The &#39;Speech-To-Text (AWS Transcribe) Statusbar-Widget&#39; plugin transcribes spoken words...",
	"ch_text":"语音转文本 （AWS Transcribe） 在 IntelliJ 中轻松捕获您的语音！“Speech-To-Text （AWS Transcribe） Statusbar-Widget”插件转录口语..."
},{
	"code":"PEDITORASSISTFO",
	"name":"Editor Assist For Code",
	"en_text":"Assist C#, Java, Kotlin, Python, C, C++, Rust, JavaScript, TypeScript, Go, PHP, Ruby development. Display document syntax in list form, convenient view and navigate...",
	"ch_text":"协助 C#、Java、Kotlin、Python、C、C++、Rust、JavaScript、TypeScript、Go、PHP、Ruby 开发。以列表形式显示文档语法，方便查看和导航..."
},{
	"code":"PRETROFITASSIT",
	"name":"Retrofit Assistant",
	"en_text":"Retrofit Assistant lets you use Retrofit more efficiently, safely, and in line with best practices. With it you can: Feature introduction Summarize all the retrofit...",
	"ch_text":"借助 Retrofit Assistant，您可以更高效、更安全地使用 Retrofit，并符合最佳实践。有了它，您可以： 功能介绍 总结所有改造..."
},{
	"code":"PARMADILLO",
	"name":"Armadillo",
	"en_text":"Armadillo is a valuable tool for debugging, documentation, analysis, and testing. By capturing the values of variables at different points in your code, you can gain...",
	"ch_text":"Armadillo 是用于调试、文档、分析和测试的宝贵工具。通过捕获代码中不同点的变量值，您可以获得..."
},{
	"code":"PAZURECODING",
	"name":"Azure Coding",
	"en_text":"Welcome to Azure Coding! Here, you can use Azure OpenAI to write code, interpret code, optimize code, and do some questions and answers yourself. This plugin by...",
	"ch_text":"欢迎使用 Azure 编码！在这里，你可以使用 Azure OpenAI 编写代码、解释代码、优化代码，以及自己做一些问题和解答。这个插件由..."
},{
	"code":"PDLXASAS",
	"name":"Alibaba Sentinel Annotation Support",
	"en_text":"Add support for Alibaba Sentinel annotation. 为 Alibaba Sentinel annotation 添加额外支持。 Attention: 注意：We have moved to using the Freemium paid model and uploaded a new...",
	"ch_text":"添加对 Alibaba Sentinel 注解的支持。为 Alibaba Sentinel annotation 添加额外支持。注意：我们已经转向使用免费增值付费模式，并上传了一个新的..."
},{
	"code":"PGODRUNNER",
	"name":"Execution God Recorder",
	"en_text":"Important: it only works with JDK 8 or higher Have you ever wondered what classes/methods are called if you do something in an application e.g. call an endpoint, click...",
	"ch_text":"重要提示：它仅适用于 JDK 8 或更高版本 您是否想过，如果您在应用程序中执行某些作（例如调用端点、单击..."
},{
	"code":"PWXUQQYVOXCRSEO",
	"name":"JavaKit",
	"en_text":"English: Java Kit is a plug-in for Java. It provides some commonly used tools, such as spring-boot + mybatis-plus code generation, and supports Java and kotlin...",
	"ch_text":"中文（简体）：Java Kit 是 Java 的插件。它提供了一些常用的工具，比如 spring-boot + mybatis-plus 代码生成，并支持 Java 和 kotlin......"
},{
	"code":"PLANGUAGEPACKIT",
	"name":"Italian Language Pack / Pacchetto Lingua Italiano",
	"en_text":"The Italian Language Pack for IntelliJ IDEs family. Il Pacchetto Lingua Italiana per la famiglia di IDE IntelliJ. Per attivare, vai su Settings | Appearance &amp;amp...",
	"ch_text":"IntelliJ IDE 的意大利语语言包系列。Il Pacchetto Lingua Italiana per la famiglia di IDE IntelliJ.Per attivare， vai su Settings |外观 &amp; ..."
},{
	"code":"PCITRIC",
	"name":"Citric",
	"en_text":"Citric is an IntelliJ-based plugin that provides framework integration for the Citrus framework. It offers various tools to generate and validate Citrus related test...",
	"ch_text":"Citric 是一个基于 IntelliJ 的插件，为 Citrus 框架提供框架集成。它提供了各种工具来生成和验证柑橘相关测试..."
},{
	"code":"PCODEQL",
	"name":"CodeQL",
	"en_text":"Provides support for CodeQl files. Features: Syntax Highlighting Basic Code Completion LSP Support.",
	"ch_text":"提供对 CodeQl 文件的支持。功能：语法高亮显示 基本代码完成 LSP 支持。"
},{
	"code":"PIMAGETOVECTOR",
	"name":"ImageToVector",
	"en_text":"ImageToVector The ImageToVector plugin is an easy and powerful tool designed to convert any image into an Android Vector Drawable or normal SVG. User Guide 1...",
	"ch_text":"ImageToVector插件是一个简单而强大的工具，旨在将任何图像转换为Android Vector Drawable或普通SVG。"
},{
	"code":"PSEQUENCEJS",
	"name":"SequenceDiagram JS",
	"en_text":"JavaScript language extension for SequenceDiagram 4.x support JavaScript, TypeScript. This extension requires a separate subscription and is used with SequenceDiagram...",
	"ch_text":"SequenceDiagram 4.x 的 JavaScript 语言扩展支持 JavaScript、TypeScript。此扩展需要单独的订阅，并与 SequenceDiagram 一起使用..."
},{
	"code":"PPKXCODEGENERAT",
	"name":"PKXCodeGenerator",
	"en_text":"PKXCodeGenerator Intro This plugin is a Java backend code generator developed based on SpringBoot and MybatisPlus, which supports both MySQL and Damon databases. After...",
	"ch_text":"PKXCodeGenerator 简介 该插件是基于 SpringBoot 和 MybatisPlus 开发的 Java 后端代码生成器，同时支持 MySQL 和 Damon 数据库。后。。。"
},{
	"code":"PAUTOAPIGENERAT",
	"name":"Auto API Generator",
	"en_text":"Auto API Generator is a powerful IntelliJ IDEA plugin for automating API creation in Spring Boot projects. Generate fully functional CRUD (Create, Read, Update...",
	"ch_text":"Auto API Generator 是一个强大的 IntelliJ IDEA 插件，用于在 Spring Boot 项目中自动创建 API。生成功能齐全的 CRUD（创建、读取、更新..."
},{
	"code":"PKUOYGHHDS",
	"name":"SSHMatrix",
	"en_text":"SSHMatrix is a powerful SSH tool that caters to all your remote server management needs. Whether you&#39;re a system administrator, a developer, or an IT professional...",
	"ch_text":"SSHMatrix 是一款功能强大的 SSH 工具，可满足您的所有远程服务器管理需求。无论您是系统管理员、开发人员还是 IT 专业人员..."
},{
	"code":"PMANAGEPROJECTS",
	"name":"Manage Projects",
	"en_text":"Project Management This is a powerful tool designed specifically for IntelliJ IDEA users, aimed at helping developers better organize and manage their projects. The...",
	"ch_text":"项目管理 这是专为 IntelliJ IDEA 用户设计的强大工具，旨在帮助开发人员更好地组织和管理他们的项目。这。。。"
},{
	"code":"PPLUGDEVKITM",
	"name":"IDE Plug DevKit Maven",
	"en_text":"Use Maven for ide plugin development Create and launch a new plugin in less than 1 minute, and use maven to manage dependencies.",
	"ch_text":"使用 Maven 进行 IDE 插件开发 在不到 1 分钟的时间内创建并启动一个新插件，并使用 maven 管理依赖项。"
},{
	"code":"PCAMUNDASTARTER",
	"name":"Camunda Starter",
	"en_text":"Provides Camunda Start New Project wizard. Camunda Start allows you to create Camunda projects through an interface instead of using the console CLI. You can set the...",
	"ch_text":"提供 Camunda Start New Project 向导。Camunda Start 允许您通过界面创建 Camunda 项目，而不是使用控制台 CLI。您可以设置..."
},{
	"code":"PCODEREFACTORAI",
	"name":"Code Refactor AI",
	"en_text":"Code Refactor AI is a plugin that enables you to refactor and write your code with AI. Beta The plugin is currently in beta. The features are very limited right now...",
	"ch_text":"Code Refactor AI 是一个插件，可让您使用 AI 重构和编写代码。Beta 插件目前处于 Beta 阶段。目前功能非常有限......"
},{
	"code":"PCOMPOSEPREVIEW",
	"name":"Compose Preview Generator",
	"en_text":"An Android Studio plugin that generates previews for @Composable functions in Android Studio. Simply install the plugin and run it with the colored squares button in...",
	"ch_text":"一个 Android Studio 插件，可在 Android Studio 中为 @Composable 函数生成预览。只需安装插件并使用彩色方块按钮运行它......"
},{
	"code":"PSNAPSHOTSFORAI",
	"name":"Snapshots for AI",
	"en_text":"Snapshots for AI helps generate machine-readable markdown snapshots of files that users are currently working on. This plugin empowers developers by providing an...",
	"ch_text":"Snapshots for AI 有助于为用户当前正在处理的文件生成机器可读的 Markdown 快照。该插件通过提供..."
},{
	"code":"PGENSETANDSET",
	"name":"GenerateSetAndGet",
	"en_text":"The plugin can generate setter methonds Getter methods by selecting a POJO object. Issues - Instructions for use: Auto: Set the value by recognizing all fields within...",
	"ch_text":"该插件可以通过选择 POJO 对象来生成 setter 方法 Getter 方法。问题 - 使用说明：自动：通过识别 MissAV.com 中的所有字段来设置值..."
},{
	"code":"PJEKADEV",
	"name":"JeKa",
	"en_text":"Plugin providing support for JeKa Build Tool. This plugin in freemium, meaning all functionalities, except code-completion, are free and will remain. Free...",
	"ch_text":"为 JeKa Build Tool 提供支持的插件。这个免费增值插件意味着除代码完成之外的所有功能都是免费的，并且将保留。自由。。。"
},{
	"code":"PDLXASASF",
	"name":"Alibaba Sentinel Annotation Support Freemium",
	"en_text":"Add support for Alibaba Sentinel annotation. 为 Alibaba Sentinel annotation 添加额外支持。 Free features: Add method navigation and auto-completion for blockHandler, fallback...",
	"ch_text":"添加对 Alibaba Sentinel 注解的支持。为 Alibaba Sentinel annotation 添加额外支持。免费功能：为 blockHandler 添加方法导航和自动完成、fallback..."
},{
	"code":"PKOTLINPARAMETE",
	"name":"Kotlin Parameter Object",
	"en_text":"Kotlin Parameter Object Simplify complex Kotlin function signatures with ease. This plugin introduces a powerful refactoring tool that extracts multiple function...",
	"ch_text":"Kotlin 参数对象 轻松简化复杂的 Kotlin 函数签名。这个插件引入了一个强大的重构工具，可以提取多个函数..."
},{
	"code":"PCLAI",
	"name":"CLAi",
	"en_text":"Command Line Ai Meet CLAi, your AI-powered Server and Infrastructure Management tool. Key Features Autonomous Command Execution: CLAi can connect to any SSH server to...",
	"ch_text":"命令行 Ai 认识 CLAi，您的 AI 驱动的服务器和基础设施管理工具。主要特点 自主命令执行：CLAi 可以连接到任何 SSH 服务器以..."
},{
	"code":"PSWISSKITCONVER",
	"name":"SwissKit Converter",
	"en_text":"The all-in-one plugin suite compatible with IntelliJ-based IDEs, brings powerful conversion tools and utilities to streamline your development workflow. From image...",
	"ch_text":"与基于 IntelliJ 的 IDE 兼容的一体化插件套件，带来强大的转换工具和实用程序，以简化您的开发工作流程。从图片..."
},{
	"code":"DPN",
	"name":"dotTrace",
	"en_text":"The dotTrace plugin is a performance profiler integrated in JetBrains Rider. Based on JetBrains dotTrace, the plugin helps developers find performance bottlenecks in a...",
	"ch_text":"dotTrace 插件是 JetBrains Rider 中集成的性能分析器。该插件基于 JetBrains dotTrace，可帮助开发人员发现..."
},{
	"code":"PBISAA",
	"name":"Android Antidecompiler",
	"en_text":"Protects Android applications with a new original algorithm (not obfuscation) against decompilation, plagiarism, and stealing. Additional details can be found on the...",
	"ch_text":"使用新的原始算法（非混淆）保护 Android 应用程序免受反编译、抄袭和窃取。更多详细信息可以在..."
},{
	"code":"PGOPARSER",
	"name":"GoParser",
	"en_text":"This Fancy IntelliJ Platform Plugin is going to be your implementation of the brilliant ideas that you have. This specific section is a source for the plugin.xml file...",
	"ch_text":"这个花哨的 IntelliJ 平台插件将成为您拥有的绝妙想法的实现。此特定部分是 plugin.xml 文件的来源..."
},{
	"code":"PAUTOLOG",
	"name":"AutoLog",
	"en_text":"Features Quickly generate logs for function arguments and return values: With a single click, you can generate logs for the arguments and return values of any...",
	"ch_text":"功能 快速生成函数参数和返回值的日志：只需单击一下，您就可以为任何参数和返回值生成日志。"
},{
	"code":"PPRSNAPVIEW",
	"name":"PR-SnapView",
	"en_text":"Summary: The PR-SnapView plugin provides an efficient way to monitor and manage GitHub Pull Requests directly from your JetBrains IDE. It generates a dynamic HTML...",
	"ch_text":"简介： PR-SnapView 插件提供了一种直接从 JetBrains IDE 监控和管理 GitHub 拉取请求的有效方法。它会生成一个动态的 HTML..."
},{
	"code":"PSEQUENCERUST",
	"name":"SequenceDiagram Rust",
	"en_text":"Rust language extension for SequenceDiagram 4.x support Rust. This extension requires a separate subscription and is used with SequenceDiagram Core. But it can&#39;t be...",
	"ch_text":"SequenceDiagram 4.x 的 Rust 语言扩展支持 Rust。此扩展需要单独的订阅，并与 SequenceDiagram Core 一起使用。但这不可能......"
},{
	"code":"PDOCGENIE",
	"name":"DocGenie",
	"en_text":"🧞‍♂️Your magical assistant for effortless code documentation generation🧞‍♂️.",
	"ch_text":"🧞 ♂️轻松生成🧞 ♂️代码文档的神奇助手。"
},{
	"code":"PSQLCOP",
	"name":"SQL COP",
	"en_text":"SQL Audit Cop - Your Intelligent SQL Audit Assistant in IntelliJ IDEA SQL Audit Cop is a powerful plugin designed specifically for the JetBrains series of IDEs (such...",
	"ch_text":"SQL Audit Cop - IntelliJ IDEA SQL Audit Cop 中的智能 SQL 审计助手是一个功能强大的插件，专为 JetBrains 系列 IDE（例如..."
},{
	"code":"PMYBATISTOOLS",
	"name":"MybatisTools",
	"en_text":"This plugin can make you easily to get the mybatis format sql,and if you have created the datasource in the Database Tools, you can also execute the sql...",
	"ch_text":"这个插件可以让你轻松获取 mybatis 格式的 sql，如果你已经在 Database Tools（数据库工具）中创建了数据源，你也可以执行 sql..."
},{
	"code":"PPRFLOWTRACKER",
	"name":"PR-FlowTracker",
	"en_text":"Summary: PR-FlowTracker is a powerful and dynamic plugin that empowers you to track Pull Requests (PRs) on GitHub directly within your JetBrains IDE. Effortlessly...",
	"ch_text":"简介： PR-FlowTracker 是一个功能强大的动态插件，使您能够直接在 JetBrains IDE 中跟踪 GitHub 上的拉取请求 （PR）。毫不费力..."
},{
	"code":"PSEQUENCEGO",
	"name":"SequenceDiagram Go",
	"en_text":"Go language extension for SequenceDiagram 4.x support GoLang. This extension requires a separate subscription and is used with SequenceDiagram Core. But it can&#39;t be...",
	"ch_text":"SequenceDiagram 4.x 的 Go 语言扩展支持 GoLang。此扩展需要单独的订阅，并与 SequenceDiagram Core 一起使用。但这不可能......"
},{
	"code":"PBACKLOG",
	"name":"Backlog Integration",
	"en_text":"Adds support for Backlog to the IDE’s task management features. To integrate Backlog with JetBrains IDEs, configure the connection under Tools | Tasks | Servers in the...",
	"ch_text":"在 IDE 的任务管理功能中添加了对 Backlog 的支持。要将 Backlog 与 JetBrains IDE 集成，请在 Tools |任务 |服务器 ..."
},{
	"code":"PSMARTINPUT",
	"name":"Smart Input Pro (Japan, South Korea, Russia &amp; more)",
	"en_text":"Automatically switch input method according to the position of the cursor. Displays the current language on the cursor. Avoid typos and coding errors caused by...",
	"ch_text":"根据光标位置自动切换输入法。在光标上显示当前语言。避免由以下原因引起的拼写错误和编码错误..."
},{
	"code":"PSEQUENCECPP",
	"name":"SequenceDiagram C/C++",
	"en_text":"C/C++ language extension for SequenceDiagram 4.x. Plugin Compatibility and Licensing This plugin is designed to work in conjunction with SequenceDiagram Core. If you...",
	"ch_text":"SequenceDiagram 4.x 的 C/C++ 语言扩展。插件兼容性和许可 此插件旨在与 SequenceDiagram Core 结合使用。如果您..."
},{
	"code":"PLANGUAGEPACKTW",
	"name":"Traditional Chinese Language Pack / IDE 本地化為繁體中文",
	"en_text":"The Chinese (Traditional) Language Pack for IJ IDEs family. IntelliJ IDE 的本地化插件轉換為繁體中文。 要啟用它，請轉到 Settings | Appearance &amp;amp; Behavior | System Settings | Language and...",
	"ch_text":"用于 IJ IDE 的中文（繁体）语言包系列。IntelliJ IDE 的本地化插件轉換為繁體中文。要啟用它，請轉到 Settings |外观与行为 |系统设置 |语言和..."
},{
	"code":"PLANGUAGEPACKCS",
	"name":"Czech Language Pack / Lokalizace IDE Do Češtiny",
	"en_text":"The Czech Language Pack for IJ IDEs family. Plugin lokalizace IntelliJ IDE do češtiny. Pro aktivaci přejděte do Settings | Appearance &amp;amp; Behavior | System Settings...",
	"ch_text":"用于 IJ IDE 的捷克语语言包系列。Plugin lokalizace IntelliJ IDE do češtiny.Pro aktivaci přejděte do Settings |外观与行为 |系统设置..."
},{
	"code":"PLANGUAGEPACKPL",
	"name":"Polish Language Pack / Lokalizacja IDE Na Język Polski",
	"en_text":"The Polish Language Pack for IJ IDEs family. Wtyczka lokalizacyjna IntelliJ IDE na język polski. Aby ją aktywować, przejdź do Settings | Appearance &amp;amp; Behavior...",
	"ch_text":"IJ IDE 的波兰语语言包系列。Wtyczka lokalizacyjna IntelliJ IDE na język polski.Aby ją aktywować， przejdź do Settings |外观和行为..."
},{
	"code":"PLANGUAGEPACKTR",
	"name":"Turkish Language Pack / IDE&#39;nin Türkçe&#39;ye Yerelleştirilmesi",
	"en_text":"The Turkish Language Pack for IJ IDEs family. IntelliJ IDE&#39;yi Türkçeye yerelleştirme eklentisi. Etkinleştirmek için Settings | Appearance &amp;amp; Behavior | System...",
	"ch_text":"IJ IDE 系列的土耳其语语言包。IntelliJ IDE'yi Türkçeye yerelleştirme eklentisi.Etkinleştirmek için Settings |外观与行为 |系统。。。"
},{
	"code":"PLANGUAGEPACKHU",
	"name":"Hungarian Language Pack / Magyar Nyelvi Csomag",
	"en_text":"The Hungarian Language Pack for IJ IDEs family. IntelliJ IDE helyi nyelvi bővítménye magyar nyelven. Az aktiváláshoz lépjen a Settings | Appearance &amp;amp; Behavior...",
	"ch_text":"用于 IJ IDE 的匈牙利语语言包系列。IntelliJ IDE helyi nyelvi bővítménye magyar nyelven.Az aktiváláshoz lépjen a Settings |外观和行为..."
}]